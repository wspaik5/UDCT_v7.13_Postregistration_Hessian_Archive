#!/usr/bin/env python3
"""Manufactured Newtonian field -> frozen constitutive source -> 3D Dirichlet solve.
EXPLORATORY numerical integration test only; NOT a galaxy field or 24-bracket validation.
"""
import sys, json, hashlib, importlib.util
from pathlib import Path
import numpy as np
from scipy.fft import dstn,idstn
R=Path('/mnt/data/v713_action_audit')
P=R/'UDCT_v7_10_Postregistration_run.py'
spec=importlib.util.spec_from_file_location('udct_frozen_coupling',P)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
# Fixed manufactured non-isotropic Newtonian potential psi = g0.x + 1/2 x.H.x
H=np.diag([1.1e-30,1.6e-30,2.3e-30]);g0=np.array([1.4e-11,-1.e-11,.7e-11]);L=1.2*m.PC

def solve(rhs,h):
 n=rhs.shape[0]; k=np.arange(1,n+1)
 ev=2*(np.cos(np.pi*k/(n+1))-1)/h**2
 return idstn(dstn(rhs,type=1,norm='ortho')/(ev[:,None,None]+ev[None,:,None]+ev[None,None,:]),type=1,norm='ortho')

def lap(u,h):
 p=np.pad(u,1)
 return (p[2:,1:-1,1:-1]+p[:-2,1:-1,1:-1]+p[1:-1,2:,1:-1]+p[1:-1,:-2,1:-1]+p[1:-1,1:-1,2:]+p[1:-1,1:-1,:-2]-6*u)/h**2

def run(n,law,ell):
 h=L/(n+1); q=(np.arange(-1,n+3)*h-L/2)
 x,y,z=np.meshgrid(q,q,q,indexing='ij')
 g=np.stack([g0[0]+H[0,0]*x,g0[1]+H[1,1]*y,g0[2]+H[2,2]*z])
 g2=np.sum(g*g,axis=0)
 nu,wh=m.gq_kernel(g2,np.array(np.sum(H*H)),ell,law)
 flux=nu[None,...]*g
 # derivative central, interior indices 2..n+1; two extra cells per side
 sl=(slice(2,-2),)*3
 div=np.zeros((n,n,n));dd=np.zeros_like(div)
 for i in range(3):
  a=flux[i];p=wh*H[i,i]
  s1=list(sl);s2=list(sl);s1[i]=slice(3,-1);s2[i]=slice(1,-3)
  div+=(a[tuple(s1)]-a[tuple(s2)])/(2*h)
  dd+=(p[tuple(s1)]-2*p[sl]+p[tuple(s2)])/h**2
 source=div-0.5*dd
 # Discrete action variation confirms relative 1/2 factor; full physical action sign/boundary not established.
 # Dirichlet phi_modified=0 on all faces is a manufactured control boundary, not a physical isolated galaxy boundary.
 phi=solve(source,h)
 residual=lap(phi,h)-source
 return {'n':n,'h_pc':h/m.PC,'center_phi_over_a0_L':float(phi[n//2,n//2]/(m.A0*L)) if False else float(phi[n//2,n//2,n//2]/(m.A0*L)),
         'mean_source_s_minus2':float(source.mean()),'source_l2_s_minus2':float(np.linalg.norm(source)/np.sqrt(source.size)),
         'rel_poisson_residual':float(np.linalg.norm(residual)/np.linalg.norm(source)),
         'rel_hessian_source_norm':float(np.linalg.norm(dd)/np.linalg.norm(source)),
         'finite':bool(np.isfinite(phi).all() and np.isfinite(source).all())}

report={'classification':'EXPLORATORY ACTION-FACTOR-CORRECTED MANUFACTURED SOURCE/POISSON; NOT HYDRUS I OR CONFIRMATORY',
 'frozen_v710_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),
 'frozen_law':'Original gq_kernel unmodified',
 'formal_source':'div(nu_eff grad psi) - 0.5*d_i d_j(wh psi_ij); factor audited by independent discrete action variation; physical action/boundary still require audit',
 'manufactured_input':'quadratic psi, constant anisotropic Hessian; no galaxy density field',
 'boundary':'zero Dirichlet modified potential on a 1.2 pc cube; NOT isolated physical boundary',
 'models':{},'not_done':['Discrete action variation factor audit passed; full physical action sign/normalization not established','No physical isolated boundary','No Hydrus I full potential','No B01-B24 Hessian-Jeans cross-test','No stellar velocity fit']}
for name in ['A-Qs','A-Qd']:
 law=next(l for l in m.PART_A_LAWS if l.name==name)
 samples=[run(n,law,L) for n in (16,24,32)]
 report['models'][name]=samples
 assert all(x['finite'] and x['rel_poisson_residual']<1e-9 for x in samples)
 print(name,[(x['n'],x['center_phi_over_a0_L'],x['rel_poisson_residual']) for x in samples],flush=True)
# QUMOND f=1 control: no Hessian source contribution
law=next(l for l in m.PART_A_LAWS if l.name=='A-Qs')
report['qumond_control']=[run(n,law,None) for n in (16,24,32)]
assert all(x['rel_hessian_source_norm']==0 for x in report['qumond_control'])
out=Path('/mnt/data/UDCT_v7_13_3D_Constitutive_Poisson_Coupling_Factor_Corrected.json')
out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('SAVED',out)

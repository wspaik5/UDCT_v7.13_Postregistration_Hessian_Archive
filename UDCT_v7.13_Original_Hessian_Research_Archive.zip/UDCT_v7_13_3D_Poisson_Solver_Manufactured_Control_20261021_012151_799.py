#!/usr/bin/env python3
"""Exploratory 3D Dirichlet Poisson solver verification; NOT a GQUMOND galaxy solution."""
from pathlib import Path
import hashlib, json, time
import numpy as np
from scipy.fft import dstn, idstn
ROOT=Path('/mnt/data/v713_3d_solver_stage')
expected={}
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h,n=line.split(maxsplit=1); expected[n]=h
for name,h in expected.items():
    actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    assert actual==h, f'Frozen file hash mismatch: {name}'

def solve_poisson_dirichlet(rhs, spacing):
    # Discrete 7-point Laplacian with zero Dirichlet boundary values.
    n=rhs.shape[0]
    assert rhs.shape==(n,n,n)
    k=np.arange(1,n+1)
    eigen1=2*(np.cos(np.pi*k/(n+1))-1)/spacing**2
    eig=eigen1[:,None,None]+eigen1[None,:,None]+eigen1[None,None,:]
    transformed=dstn(rhs,type=1,norm='ortho')
    return idstn(transformed/eig,type=1,norm='ortho')

def laplacian_7pt(u,h):
    z=np.pad(u,1)
    return (z[2:,1:-1,1:-1]+z[:-2,1:-1,1:-1]+z[1:-1,2:,1:-1]+z[1:-1,:-2,1:-1]+z[1:-1,1:-1,2:]+z[1:-1,1:-1,:-2]-6*u)/h**2

results=[]
start=time.monotonic()
for n in (24,48,96):
    h=1/(n+1)
    x=np.arange(1,n+1)*h
    sx=np.sin(np.pi*x)
    exact=sx[:,None,None]*sx[None,:,None]*sx[None,None,:]
    rhs=-3*np.pi**2*exact
    solution=solve_poisson_dirichlet(rhs,h)
    residual=laplacian_7pt(solution,h)-rhs
    relerr=float(np.linalg.norm(solution-exact)/np.linalg.norm(exact))
    relres=float(np.linalg.norm(residual)/np.linalg.norm(rhs))
    results.append({'interior_cells_per_axis':n,'h_box_fraction':h,'relative_L2_error_vs_continuum':relerr,'relative_L2_discrete_residual':relres,'max_abs_error':float(np.max(abs(solution-exact)))})
ratios=[results[i]['relative_L2_error_vs_continuum']/results[i+1]['relative_L2_error_vs_continuum'] for i in range(2)]
assert all(r['relative_L2_discrete_residual']<1e-10 for r in results)
assert all(3.5<ratio<4.5 for ratio in ratios)
report={'classification':'EXPLORATORY 3D POISSON MANUFACTURED-SOLUTION CONTROL; NOT MODIFIED-GRAVITY OR HYDRUS I FIELD SOLUTION',
        'frozen_files_verified':len(expected),'test':'Dirichlet zero boundary, analytic Phi=sin(pi x)sin(pi y)sin(pi z), Laplacian Phi=-3 pi^2 Phi, unit cube',
        'method':'7-point finite difference Laplacian solved with orthonormal DST-I; independent finite-difference residual',
        'grids':results,'error_reduction_ratios':ratios,'elapsed_seconds':round(time.monotonic()-start,3),
        'not_performed':['No A-Qs or A-Qd galaxy source computed','No 3D Newtonian potential of Hydrus I solved','No 3D GQUMOND modified potential solved','No modified-potential Hessian on B01-B24','No direct fit to individual stellar velocities'],
        'next_gate':'Derive and independently audit sign/units and boundary conditions of the full GQUMOND source; then construct physically grounded 3D Newtonian field and solve modified Poisson equation.'}
out=Path('/mnt/data/UDCT_v7_13_3D_Poisson_Manufactured_Control.json')
out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'grids':results,'error_reduction_ratios':ratios,'verified_frozen_files':len(expected),'output':str(out)},indent=2))

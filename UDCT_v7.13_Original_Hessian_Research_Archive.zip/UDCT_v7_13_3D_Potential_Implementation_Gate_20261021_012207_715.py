#!/usr/bin/env python3
"""Read-only, reproducible source-level implementation gate; not a galaxy simulation."""
import ast,hashlib,json,pathlib,datetime
root=pathlib.Path('/mnt/data/v713_hessian_stage')
files=['UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py','UDCT_v7_10_Postregistration_run.py','UDCT_v7_11_Preregistration_Anisotropic_Jeans.py','UDCT_v7_12_Preregistration_Jeans_Transition.py']
result={'audit_type':'source-level implementation inventory (not numerical Hessian validation)','files':{},'criteria':{'3d_total_modified_potential_solver':'not identified','external_newtonian_tidal_hessian':'identified','angle_averaged_radial_jeans':'identified','B01_B24_3d_modified_hessian':'NOT EVALUATED'},'limitations':['AST/function inspection cannot prove mathematical nonexistence of a solver elsewhere','Existing Newtonian external tidal Hessian is not total modified-gravity potential Hessian','No 3D modified-gravity field equation was solved; no observational fit performed']}
for name in files:
 p=root/name; s=p.read_text(); tree=ast.parse(s); funcs=[x.name for x in ast.walk(tree) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))]
 result['files'][name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'functions_of_interest':[f for f in funcs if any(k in f.lower() for k in ('potential','hessian','field','kernel','geometry','model_state','jeans','force','poisson'))]}
result['specific_findings']={'v706_galactic_field':'returns external visible-mass gradient and Hessian at Hydrus I location','v710_geometry':'uses local linearized external field e + H x and analytic radial internal field','v710_model_state':'angle-averages constitutive response over directions; returns radial state, not 3D total potential','v712':'uses inherited radial Jeans solver and frozen model code'}
out=pathlib.Path('/mnt/data/UDCT_v7_13_3D_Potential_Implementation_Gate.json');out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps(result,indent=2,ensure_ascii=False))

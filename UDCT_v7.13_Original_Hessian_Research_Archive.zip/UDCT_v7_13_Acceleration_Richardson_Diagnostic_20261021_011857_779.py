#!/usr/bin/env python3
"""Exploratory three-grid h^2 extrapolation of EXISTING fixed-box results.
Not a new 3D solve; not a preregistered B01-B24 decision.
"""
import json, hashlib
from pathlib import Path
src=Path(__file__).with_name('UDCT_v7_13_Fixed_Box_Resolution_Audit.json')
raw=src.read_bytes(); data=json.loads(raw)
results=[]
for law in ('A-Qs','A-f1/2'):
    records=sorted((r for r in data['results'] if r['law']==law),key=lambda r:r['spacing_over_rh'],reverse=True)
    assert [r['n'] for r in records]==[23,35,47]
    fields={}
    for key in ('center_delta_phi_over_a0_rh','center_delta_acceleration_over_a0'):
        x=[r['spacing_over_rh']**2 for r in records]
        y=[r[key] for r in records]
        def extrap(i,j):return (x[i]*y[j]-x[j]*y[i])/(x[i]-x[j])
        coarse=extrap(0,1); fine=extrap(1,2)
        fields[key]={'samples':y,'h2_extrap_23_35':coarse,'h2_extrap_35_47':fine,'pair_extrap_disagreement_fraction':abs(coarse-fine)/max(abs(fine),1e-300),'fine_grid_vs_fine_extrap_fraction':abs(y[2]-fine)/max(abs(fine),1e-300)}
    results.append({'law':law,'ell_pc':10,'box_side_rh':6,'metrics':fields})
out={'status':'EXPLORATORY_POSTPROCESS_ONLY','input_file':src.name,'input_sha256':hashlib.sha256(raw).hexdigest(),'assumption':'leading O(h^2) truncation error, not independently established; fixed finite zero-Dirichlet boundary','limitations':['No new Poisson solves','Extrapolation is not a convergence proof','No finite-box boundary correction','Central acceleration magnitude is not a Jeans or observational fit','No preregistered B01-B24 decisions'],'results':results}
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(out,indent=2)+'\n')
for r in results:
 print(r['law'])
 for key,v in r['metrics'].items(): print(' ',key,'fine extrap',v['h2_extrap_35_47'],'pair disagreement',f"{100*v['pair_extrap_disagreement_fraction']:.3f}%",'fine-to-extrap',f"{100*v['fine_grid_vs_fine_extrap_fraction']:.3f}%")
print('Saved',path)

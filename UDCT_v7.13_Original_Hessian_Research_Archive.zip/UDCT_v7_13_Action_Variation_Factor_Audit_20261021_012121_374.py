#!/usr/bin/env python3
"""Exploratory discrete action variation audit, not a galaxy calculation."""
from pathlib import Path
import zipfile,hashlib,json,sys,importlib.util
import numpy as np
ZIP=Path('/mnt/data/UDCT_v7_13_Preregistration_Complete_Updated.zip')
R=Path('/mnt/data/v713_action_audit');R.mkdir(exist_ok=True)
with zipfile.ZipFile(ZIP) as z:
 plan=json.loads(z.read('preregistration_plan.json'))
 for name,digest in plan['frozen_hashes'].items():
  data=z.read(name);assert hashlib.sha256(data).hexdigest()==digest,name
  (R/name).write_bytes(data)
spec=importlib.util.spec_from_file_location('udct_v710_action',R/'UDCT_v7_10_Postregistration_run.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
rng=np.random.default_rng(713)
n=14;L=1.0;h=L/n
x=np.arange(n)*2*np.pi/n
X,Y,Z=np.meshgrid(x,x,x,indexing='ij')
base=0.16*np.sin(X)+0.11*np.cos(Y+Z)+0.08*np.sin(X+2*Y-Z)
pert=rng.normal(size=base.shape);pert/=np.linalg.norm(pert)
external=np.array([1.1,-0.7,0.5])
def D(a,i):return (np.roll(a,-1,axis=i)-np.roll(a,1,axis=i))/(2*h)
def derivs(a):
 g=np.stack([external[i]+D(a,i) for i in range(3)])
 H=np.stack([[D(D(a,j),i) for j in range(3)] for i in range(3)])
 return g,H

def calc(a,law):
 g,H=derivs(a);z=np.sum(g*g,axis=0);s=np.sum(H*H,axis=(0,1));u=z/s;f=u**law.n/(1+u**law.n);w=z/f
 P=f*m.q_closed(law.nu,w)
 nu,wh=m.gq_kernel(z*m.A0**2,s*m.A0**2,1.,law)
 nu=np.asarray(nu);wh=np.asarray(wh)
 div=sum(D(nu*g[i],i) for i in range(3))
 dd=sum(D(D(wh*H[i,j],j),i) for i in range(3) for j in range(3))
 return P.sum(),div,dd
out={'status':'EXPLORATORY discrete action audit; not galaxy result','source_sha256_verified':True,'assumed_action_density':'P=f(u)Q(Z/f), Z=|grad psi|^2/a0^2, u=|grad psi|^2/(ell^2 H:H)','tested_identity':'delta sum(P)/delta psi = -2 div(nu grad psi)+divdiv(wh H), hence normalized source div-0.5 divdiv','previous_prototype_source':'div-dd (factor 2 on Hessian term)','laws':{}}
for name in ['A-Qs','A-Qd']:
 law=next(t for t in m.PART_A_LAWS if t.name==name)
 action,div,dd=calc(base,law)
 eps=1e-4
 plus=calc(base+eps*pert,law)[0];minus=calc(base-eps*pert,law)[0]
 fd=(plus-minus)/(2*eps)
 predicted=float(np.sum((-2*div+dd)*pert))
 old=float(np.sum((-2*div+2*dd)*pert))
 err=abs(fd-predicted)/max(abs(fd),1e-15)
 err_old=abs(fd-old)/max(abs(fd),1e-15)
 assert err<2e-5,(name,err)
 out['laws'][name]={'directional_finite_difference':fd,'action_consistent_prediction':predicted,'relative_error_corrected':err,'previous_div_minus_dd_prediction_scaled_to_action':old,'relative_error_previous':err_old,'dd_projection':float(np.sum(dd*pert))}
 print(name,'FD',fd,'correct relerr',err,'old relerr',err_old,flush=True)
out['limitation']='Discrete periodic manufactured field, exact variation of chosen P only; does not prove full physical action normalization, boundary conditions, or 3D galaxy solutions.'
path=Path('/mnt/data/UDCT_v7_13_Action_Variation_Factor_Audit.json');path.write_text(json.dumps(out,indent=2)+'\n');print('SAVED',path)

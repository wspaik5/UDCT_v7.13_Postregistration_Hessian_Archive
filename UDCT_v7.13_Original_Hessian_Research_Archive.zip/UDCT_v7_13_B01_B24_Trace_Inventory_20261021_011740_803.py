from pathlib import Path
import json,hashlib,numpy as np
R=Path('/mnt/data')
ranges=[(2,3),(4,4),(5,6),(7,9),(10,10),(11,12),(13,15),(16,17),(18,18),(19,20),(21,22),(23,24)]
records=[json.loads((R/'UDCT_v7_13_B01_Full_Profile_Trace.json').read_text())]
profiles={}
with np.load(R/'UDCT_v7_13_B01_Full_Common_Profiles.npz') as z:
 for key in z.files: profiles['B01|'+key]=z[key]
for a,b in ranges:
 stem=f'UDCT_v7_13_B{a:02d}_B{b:02d}_Full'
 obj=json.loads((R/(stem+'_Profile_Trace.json')).read_text())
 assert obj['profile_count']==12*(b-a+1)
 archive=R/(stem+'_Common_Profiles.npz')
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==obj['profile_archive_sha256']
 records+=obj['targets']
 with np.load(archive) as z:
  for key in z.files:
   assert key not in profiles
   profiles[key]=z[key]
assert len(records)==24 and len(profiles)==288
for i,rec in enumerate(records,1):
 if i==1: assert rec['target']=='B01'
 else: assert rec['target']==f'B{i:02d}'
 assert rec['bracket_status']=='unresolved_numerical_margin'
for vec in profiles.values(): assert len(vec)==1200 and np.isfinite(vec).all()
archive=R/'UDCT_v7_13_B01_B24_All_Common_Profiles.npz'
np.savez_compressed(archive,**profiles)
out={'classification':'EXPLORATORY_REPRODUCIBILITY_TRACE_NOT_CONFIRMATORY','targets':24,'six_arm_endpoint_profiles':288,'common_radial_points_per_profile':1200,'bracket_status_counts':{'unresolved_numerical_margin':24},'full_profiles_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'target_summary':[{'target':f'B{i:02d}','status':r['bracket_status'],'endpoints':r['endpoints']} for i,r in enumerate(records,1)],'limits':['Prototype decision not independently validated','Only current bracket endpoints recalculated; historical bisection attempt histories not reproduced','3D Hessian not evaluated','No observational individual-star fitting','Publication chronology of prereg amendment unverified']}
(R/'UDCT_v7_13_B01_B24_Trace_Inventory.json').write_text(json.dumps(out,indent=2)+'\n')
print('VERIFIED',len(records),'targets',len(profiles),'profiles',archive.stat().st_size,'bytes')

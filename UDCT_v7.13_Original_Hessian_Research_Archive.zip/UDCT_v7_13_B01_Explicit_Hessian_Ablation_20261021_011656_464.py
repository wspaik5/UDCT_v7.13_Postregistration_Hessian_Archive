#!/usr/bin/env python3
"""Exploratory explicit stress-divergence ablation, holding nu_eff and density fixed.
Not a variationally consistent independent gravity law or preregistered Hessian validation.
"""
from pathlib import Path
import importlib.util,sys,json,hashlib
import numpy as np
ROOT=Path('/mnt/data/UDCT_v7_13_Confirmatory_Gate_Staging')
plan=json.loads((ROOT/'preregistration_plan.json').read_text())
for name,digest in plan['frozen_hashes'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
spec=importlib.util.spec_from_file_location('v712_ablation',ROOT/'UDCT_v7_12_Preregistration_Jeans_Transition.py')
v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
m=v.load_frozen(); b=m.load_baseline(); obj=b.DWARFS['Hydrus I']
rows=[]
for grid_name in ('default','refined'):
    grid=b.make_grid(grid_name); e,h=b.V706.galactic_field(obj,grid)[:2]
    ratios=b.mesh('Tapered cusp',grid,rmin=.0005)
    st=b.model_state(obj,'Tapered cusp',ratios,e,h,grid,b.BASE_LAW,1.,0.)
    r=st['r']; x=r/st['rh'];rho=st['rho']; vref=float(np.interp(1.,x,st['gn']))*st['rh']
    full=b.V706.work_from_state(st)[1]
    noexplicit=st['lead'].copy()
    hess=full-noexplicit
    for beta in (.35,.40):
        series={}
        for label,force in [('full',full),('screened_nu_only',noexplicit)]:
            p,_,_=m.solve(r,rho,force,beta)
            f=np.divide(p,rho*vref,out=np.full_like(p,np.nan),where=rho>1e-280)
            mask=(x>=.0005)&(x<=.002)&np.isfinite(f)
            roots=[]
            inds=np.flatnonzero((f[:-1]*f[1:]<0)&(x[:-1]<.002)&np.isfinite(f[:-1])&np.isfinite(f[1:]))
            for i in inds:
                t=-f[i]/(f[i+1]-f[i]);roots.append(float(np.exp(np.log(x[i])+t*(np.log(x[i+1])-np.log(x[i])))))
            series[label]={'F_inner':float(f[0]),'F_min_inner':float(np.min(f[mask])),'F_at_002':float(np.interp(.002,x,f)),'zero_rh':roots,'negative_inner_samples':int(np.sum(f[mask]<0))}
        rows.append({'grid':grid_name,'beta':beta,'explicit_stress_force_inner_over_gn':float(hess[0]/st['gn'][0]),'models':series})
    print('completed',grid_name,flush=True)
result={'status':'EXPLORATORY_EXPLICIT_STRESS_TERM_ABLATION','verified_frozen_hashes':True,'definition':'Hold GQUMOND screened nu_eff lead fixed, set explicit -1/2 divergence of wh*Hessian stress to zero in Jeans force; compare full force with lead only','rows':rows,'limitations':['This is NOT a valid standalone action-derived modified gravity model','Removing explicit stress term does not remove Hessian dependence inside nu_eff through screening f(u)','Uses inherited approximate radial force and Jeans solver, not independent 3D field Hessian','Inner-radius sign changes are exploratory and not registered B01 beta-boundary decisions','No direct observational fit']}
out=Path('/mnt/data/UDCT_v7_13_B01_Explicit_Hessian_Ablation.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(rows,indent=2));print(out)

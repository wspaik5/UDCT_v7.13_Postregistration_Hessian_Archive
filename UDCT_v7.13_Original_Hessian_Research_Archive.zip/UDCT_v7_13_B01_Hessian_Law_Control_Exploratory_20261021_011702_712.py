#!/usr/bin/env python3
"""B01 fixed-physics GQUMOND versus QUMOND-control radial Jeans zero diagnostic.
Exploratory only; no 3D Hessian isolation, no preregistered boundary decision.
"""
from pathlib import Path
import json,hashlib,importlib.util,sys
import numpy as np
R=Path('/mnt/data/UDCT_v7_13_Confirmatory_Gate_Staging')
plan=json.loads((R/'preregistration_plan.json').read_text())
for name,digest in plan['frozen_hashes'].items():
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
spec=importlib.util.spec_from_file_location('v712_hessiancontrol',R/'UDCT_v7_12_Preregistration_Jeans_Transition.py')
v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
m=v.load_frozen();b=m.load_baseline();obj=b.DWARFS['Hydrus I']
rows=[]
for grid_name in ('default','refined'):
    grid=b.make_grid(grid_name);e,h=b.V706.galactic_field(obj,grid)[:2]
    ratios=b.mesh('Tapered cusp',grid,rmin=.0005)
    for label,law,ell in [('BASE_GQ',b.BASE_LAW,1.),('BASE_QUMOND',b.BASE_LAW,None),('A_fhalf_GQ',b.PART_A_LAWS[0],1.),('A_Qs_GQ',b.PART_A_LAWS[2],1.)]:
        st=b.model_state(obj,'Tapered cusp',ratios,e,h,grid,law,ell,0.)
        _,force=b.V706.work_from_state(st)
        x=st['r']/st['rh'];rho=st['rho'];vref=float(np.interp(1.,x,st['gn']))*st['rh']
        for beta in (.35,.40):
            p,_,_=m.solve(st['r'],rho,force,beta)
            f=p/rho/vref
            mask=(x>=.0005)&(x<=.002)
            idx=np.flatnonzero((f[:-1]*f[1:]<0)&(x[:-1]<.002))
            roots=[]
            for i in idx:
                t=-f[i]/(f[i+1]-f[i]);roots.append(float(np.exp(np.log(x[i])+t*(np.log(x[i+1])-np.log(x[i])))))
            rows.append({'grid':grid_name,'model':label,'beta':beta,'ell_pc':ell,'min_inner_F':float(np.min(f[mask])),'F_at_inner':float(f[0]),'F_at_002':float(np.interp(.002,x,f)),'zero_rh':roots,'negative_inner_samples':int(np.sum(f[mask]<0)),'finite_inner':bool(np.isfinite(f[mask]).all())})
        print('done',grid_name,label,flush=True)
result={'status':'EXPLORATORY_GQ_VS_QUMOND_AND_LAW_COMPARISON','frozen_hashes_verified':True,'rows':rows,'limitations':['QUMOND control removes screening and Hessian kernel together, NOT a selective Hessian-term ablation','A-f1/2 and A-Qs change constitutive law and cannot isolate Hessian causal effect','No full 3D Hessian field solve or independent force solver','Root estimates are log-radius interpolations; only inner region assessed','No registered B01-B24 decisions modified']}
out=Path('/mnt/data/UDCT_v7_13_B01_Hessian_Law_Control_Exploratory.json');out.write_text(json.dumps(result,indent=2)+'\n')
print('saved',out)

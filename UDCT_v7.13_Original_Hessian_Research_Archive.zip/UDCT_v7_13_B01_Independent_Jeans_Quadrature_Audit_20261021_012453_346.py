#!/usr/bin/env python3
"""Exploratory independent integration audit for B01. Not a six-arm field validation."""
from pathlib import Path
import importlib.util, sys, json, hashlib
import numpy as np
from scipy.integrate import cumulative_simpson
ROOT=Path('/mnt/data/v713_post_work')
plan=json.loads((ROOT/'preregistration_plan.json').read_text())
for name,digest in plan['frozen_hashes'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
spec=importlib.util.spec_from_file_location('v712frozen',ROOT/'UDCT_v7_12_Preregistration_Jeans_Transition.py')
v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
m=v.load_frozen(); b=m.load_baseline(); obj=b.DWARFS['Hydrus I']
results=[]
for gridname in ('default','refined'):
    grid=b.make_grid(gridname);e,h=b.V706.galactic_field(obj,grid)[:2]
    for inner in (.002,.0005):
        st=b.model_state(obj,'Tapered cusp',b.mesh('Tapered cusp',grid,rmin=inner),e,h,grid,b.BASE_LAW,1.,0.)
        _,force=b.V706.work_from_state(st)
        r,rho=st['r'],st['rho'];vref2=float(np.interp(1.,r/st['rh'],st['gn']))*st['rh']
        for beta in (.35,.40):
            p_trap,_,q=m.solve(r,rho,force,beta,0.)
            # Independent integration rule (composite Simpson on nonuniform radial mesh).
            y=q*rho*force;x=r
            cumulative=cumulative_simpson(y,x=x,initial=0.)
            integral=cumulative[-1]-cumulative
            p_simp=integral/q
            mask=(r/st['rh']<=10.)&(rho>1e-280)
            trap=p_trap[mask]/rho[mask]/vref2
            simp=p_simp[mask]/rho[mask]/vref2
            results.append({'grid':gridname,'inner_rh':inner,'beta':beta,
                'trapezoid_min_normalized':float(trap.min()),
                'simpson_min_normalized':float(simp.min()),
                'max_abs_normalized_profile_difference':float(np.max(abs(trap-simp))),
                'trapezoid_sign':int(np.sign(trap.min())),
                'simpson_sign':int(np.sign(simp.min()))})
report={'status':'EXPLORATORY quadrature-only check; not independent gravitational field or six-arm validation',
        'frozen_hashes_verified':True,'target':'B01','hessian_performed':False,'six_arm_validation_performed':False,'results':results}
path=Path('/mnt/data/UDCT_v7_13_B01_Quadrature_Audit.json')
path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

#!/usr/bin/env python3
"""Exploratory B01 radial zero sensitivity to inner cutoff, frozen v7.12 physics."""
import json,hashlib,importlib.util,sys
from pathlib import Path
import numpy as np
R=Path('/mnt/data/UDCT_v7_13_Confirmatory_Gate_Staging')
plan=json.loads((R/'preregistration_plan.json').read_text())
for name,digest in plan['frozen_hashes'].items():
 assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
spec=importlib.util.spec_from_file_location('v712_cutoff_audit',R/'UDCT_v7_12_Preregistration_Jeans_Transition.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
old=m.load_frozen();b=old.load_baseline();obj=b.DWARFS['Hydrus I']
rows=[]
for grid_name in ('default','refined'):
 grid=b.make_grid(grid_name);e,h=b.V706.galactic_field(obj,grid)[:2]
 for inner in (.00025,.0005,.00075,.001):
  st=b.model_state(obj,'Tapered cusp',b.mesh('Tapered cusp',grid,rmin=inner),e,h,grid,b.BASE_LAW,1.0,0.)
  _,force=b.V706.work_from_state(st);x=st['r']/st['rh']
  pressure,_,_=old.solve(st['r'],st['rho'],force,.35)
  f=pressure/st['rho']/(float(np.interp(1.,x,st['gn']))*st['rh'])
  idx=np.flatnonzero((f[:-1]*f[1:]<0)&(x[:-1]<.002))
  roots=[]
  for i in idx:
   t=-f[i]/(f[i+1]-f[i]);roots.append(float(np.exp(np.log(x[i])+t*(np.log(x[i+1])-np.log(x[i])))))
  rows.append({'grid':grid_name,'inner_rh':inner,'root_rh':roots,'min_F':float(np.min(f[x<=10])),'F_at_inner':float(f[0]),'F_at_002':float(np.interp(.002,x,f)),'native_grid_size':len(x)})
  print(grid_name,inner,roots,flush=True)
result={'status':'EXPLORATORY_CUTOFF_SENSITIVITY_NOT_PREREGISTERED','frozen_hashes_verified':True,'beta':.35,'law':'BASE','ell_pc':1.0,'rows':rows,'limitations':['Only B01 beta 0.35, Tapered cusp, fixed frozen law','Changes inner radial cutoff beyond registered 0.0005 and 0.002 are exploratory','Roots are log-linear interpolations','No Hessian calculation or observed stellar velocity fit','No preregistered B01-B24 classification changes']}
out=Path('/mnt/data/UDCT_v7_13_B01_Inner_Cutoff_Stability.json');out.write_text(json.dumps(result,indent=2)+'\n')

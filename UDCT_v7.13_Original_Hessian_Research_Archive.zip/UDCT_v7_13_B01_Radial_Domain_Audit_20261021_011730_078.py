#!/usr/bin/env python3
"""Audit B01 native-vs-common minimum locations without modifying frozen physics."""
import json, hashlib, importlib.util, sys
from pathlib import Path
import numpy as np
R=Path('/mnt/data/UDCT_v7_13_Confirmatory_Gate_Staging')
plan=json.loads((R/'preregistration_plan.json').read_text())
for name,sha in plan['frozen_hashes'].items():
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha,name

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod
old=load(R/'UDCT_v7_12_Preregistration_Jeans_Transition.py','v712_domain')
m=old.load_frozen(); b=m.load_baseline(); obj=b.DWARFS['Hydrus I']
common=np.geomspace(.002,10.,1200)
rows=[]
for grid_name in ['default','refined']:
    grid=b.make_grid(grid_name)
    e,h=b.V706.galactic_field(obj,grid)[:2]
    for inner in [.002,.0005]:
        st=b.model_state(obj,'Tapered cusp',b.mesh('Tapered cusp',grid,rmin=inner),e,h,grid,b.BASE_LAW,1.0,0.)
        _,force=b.V706.work_from_state(st)
        for beta in [.35,.40]:
            rec=m.summary(st['r'],st['rho'],force,beta,st['rh'],st['gn'])
            vref2=rec['vref2_si']
            native=rec['min_sigma2_kms2']*1e6/vref2
            cmin=min(rec['common_sigma2_over_vref2'])
            rows.append(dict(grid=grid_name,inner_rh=inner,beta=beta,native_min=float(native),native_min_radius_rh=float(rec['min_at_r_over_rh']),common_min=float(cmin),common_start_rh=float(common[0]),minimum_below_common_domain=bool(rec['min_at_r_over_rh']<common[0]),native_common_gap=float(cmin-native)))
result={'status':'EXPLORATORY_DOMAIN_DIAGNOSTIC_NOT_CONFIRMATORY','frozen_hashes_verified':True,'common_domain_rh':[float(common[0]),float(common[-1])],'rows':rows,'limitations':['B01 only','Original grid minimum is a discrete sampled minimum','No new registered sign decisions or independent solver validation']}
p=Path('/mnt/data/UDCT_v7_13_B01_Radial_Domain_Audit.json');p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

#!/usr/bin/env python3
"""B01 radial sign-change exploration; frozen physics, no altered prereg criteria."""
import json,hashlib,importlib.util,sys
from pathlib import Path
import numpy as np
R=Path('/mnt/data/UDCT_v7_13_Confirmatory_Gate_Staging')
plan=json.loads((R/'preregistration_plan.json').read_text())
for name,digest in plan['frozen_hashes'].items():
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
spec=importlib.util.spec_from_file_location('udct712_radialzero',R/'UDCT_v7_12_Preregistration_Jeans_Transition.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
m=old.load_frozen(); b=m.load_baseline(); obj=b.DWARFS['Hydrus I']
rows=[]
for grid_name in ('default','refined','validation'):
    grid=b.make_grid(grid_name) if grid_name!='validation' else b.Grid(radial=1440,polar=96,azimuth=144,disk_radial=480,disk_azimuth=256,disk_height=48)
    e,h=b.V706.galactic_field(obj,grid)[:2]
    st=b.model_state(obj,'Tapered cusp',b.mesh('Tapered cusp',grid,rmin=.0005),e,h,grid,b.BASE_LAW,1.0,0.)
    _,force=b.V706.work_from_state(st)
    x=st['r']/st['rh']
    for beta in (.35,.40):
        pressure,_,_=m.solve(st['r'],st['rho'],force,beta)
        f=pressure/st['rho']/(float(np.interp(1.,x,st['gn']))*st['rh'])
        inds=np.flatnonzero((f[:-1]*f[1:]<0)&(x[:-1]<.002))
        roots=[]
        for i in inds:
            # linear in log-radius is an interpolated discrete root, not continuum physical threshold
            t=-f[i]/(f[i+1]-f[i]); xr=float(np.exp(np.log(x[i])+t*(np.log(x[i+1])-np.log(x[i]))))
            roots.append(dict(left_rh=float(x[i]),right_rh=float(x[i+1]),interpolated_rh=xr,left_F=float(f[i]),right_F=float(f[i+1])))
        rows.append(dict(grid=grid_name,beta=beta,inner_rh=.0005,native_min=float(np.min(f[x<=10])),inner_F=float(f[0]),at_002_F=float(np.interp(.002,x,f)),sign_crossings_below_002=roots,negative_band_rh=([float(x[(f<0)&(x<=10)].min()),float(x[(f<0)&(x<=10)].max())] if np.any((f<0)&(x<=10)) else None),n_grid=int(len(x))))
    print('finished',grid_name,flush=True)
result=dict(status='EXPLORATORY_RADIAL_ZERO_NOT_PREREGISTERED_BETA_BRACKET',frozen_hashes_verified=True,rows=rows,limitations=['Zero estimates are log-radius interpolations of sampled profiles','Only B01 BASE at ell=1 pc and inner cutoff 0.0005 rh','No physical threshold, convergence proof, 3D Hessian or observational fit','Registered beta sign-boundary classifications unchanged'])
p=Path('/mnt/data/UDCT_v7_13_B01_Radial_Zero_Exploratory.json');p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(rows,indent=2))

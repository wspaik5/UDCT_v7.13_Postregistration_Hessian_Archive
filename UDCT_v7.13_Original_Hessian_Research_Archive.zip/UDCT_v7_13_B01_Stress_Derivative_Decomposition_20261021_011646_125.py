#!/usr/bin/env python3
"""Exploratory decomposition of explicit GQUMOND stress force in frozen B01.
NOT a new theory, preregistered confirmation, or physical Hessian measurement.
"""
from pathlib import Path
import importlib.util, sys, json, hashlib
import numpy as np
ROOT=Path('/mnt/data/UDCT_v7_13_Confirmatory_Gate_Staging')
plan=json.loads((ROOT/'preregistration_plan.json').read_text())
hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in plan['frozen_hashes']}
assert all(hashes[n]==v for n,v in plan['frozen_hashes'].items())
spec=importlib.util.spec_from_file_location('v712_stress_split',ROOT/'UDCT_v7_12_Preregistration_Jeans_Transition.py')
v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
m=v.load_frozen();b=m.load_baseline();obj=b.DWARFS['Hydrus I']
rows=[]
for grid_name in ('default','refined'):
 grid=b.make_grid(grid_name);e,h=b.V706.galactic_field(obj,grid)[:2]
 ratios=b.mesh('Tapered cusp',grid,rmin=.0005)
 st=b.model_state(obj,'Tapered cusp',ratios,e,h,grid,b.BASE_LAW,1.,0.)
 r=st['r'];x=r/st['rh'];rho=st['rho'];vref=float(np.interp(1.,x,st['gn']))*st['rh']
 lead=st['lead'];pnn=st['pnn'];trp=st['trp']
 grad=-.5*np.gradient(pnn,r,edge_order=2)
 geom=-.5*(3*pnn-trp)/r
 forces={'screened_lead':lead,'lead_plus_radial_derivative':lead+grad,'lead_plus_geometric_stress':lead+geom,'full':lead+grad+geom}
 for beta in (.35,.40):
  vals={}
  for label,force in forces.items():
   p,_,_=m.solve(r,rho,force,beta)
   F=np.divide(p,rho*vref,out=np.full_like(p,np.nan),where=rho>1e-280)
   mask=(x>=.0005)&(x<=.002)&np.isfinite(F)
   roots=[]
   for i in np.flatnonzero((F[:-1]*F[1:]<0)&(x[:-1]<.002)&np.isfinite(F[:-1])&np.isfinite(F[1:])):
    t=-F[i]/(F[i+1]-F[i]);roots.append(float(np.exp(np.log(x[i])+t*(np.log(x[i+1])-np.log(x[i])))))
   vals[label]={'F_inner':float(F[0]),'F_min_inner':float(np.min(F[mask])),'negative_inner_samples':int(np.sum(F[mask]<0)),'zero_rh':roots}
  # Because Jeans solve is linear in force at fixed rho,beta, calculate contributions relative to lead.
  F0=vals['screened_lead']['F_inner'];Fg=vals['lead_plus_radial_derivative']['F_inner'];Ft=vals['lead_plus_geometric_stress']['F_inner'];Ffull=vals['full']['F_inner']
  rows.append({'grid':grid_name,'beta':beta,'force_at_inner_over_gn':{'lead':float(lead[0]/st['gn'][0]),'radial_derivative':float(grad[0]/st['gn'][0]),'geometric_stress':float(geom[0]/st['gn'][0]),'total':float((lead[0]+grad[0]+geom[0])/st['gn'][0])},'F_inner_contributions':{'lead':F0,'radial_derivative':Fg-F0,'geometric_stress':Ft-F0,'sum':F0+(Fg-F0)+(Ft-F0),'full':Ffull,'linearity_residual':Ffull-(Fg+Ft-F0)},'variants':vals})
 print('completed',grid_name,flush=True)
out={'status':'EXPLORATORY_STRESS_FORCE_DECOMPOSITION','verified_frozen_hashes':hashes,'setup':'Hydrus I B01 BASE law, ell=1 pc, tapered cusp, rmin=0.0005rh, beta 0.35/0.40','formula':'g_full = g_lead - 0.5 d(pnn)/dr - 0.5(3pnn-trp)/r','rows':rows,'limitations':['Each force term decomposition is diagnostic; individual partial forces are not action-derived standalone gravity laws','The derivative term is a radial derivative of the angular-averaged stress pnn, not a separate independent Hessian tensor component','The Jeans solve and radial field approximation are inherited, not independently implemented','No 3D total-potential Hessian validation or observational fit','Inner-radius roots are exploratory, not registered B01-B24 beta boundaries']}
path=Path('/mnt/data/UDCT_v7_13_B01_Stress_Derivative_Decomposition.json');path.write_text(json.dumps(out,indent=2)+'\n')
for row in rows:print(row['grid'],row['beta'],row['F_inner_contributions'],{k:v['zero_rh'] for k,v in row['variants'].items()})
print(path)

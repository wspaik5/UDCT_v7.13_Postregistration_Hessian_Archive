#!/usr/bin/env python3
"""B02-B24 exploratory six-arm full-profile archival. Frozen physics; no 3D Hessian."""
from pathlib import Path
import json,csv,hashlib,importlib.util,sys,time
import numpy as np
R=Path('/mnt/data/UDCT_v7_13_Confirmatory_Gate_Staging')
OUT=Path('/mnt/data')
plan=json.loads((R/'preregistration_plan.json').read_text())
for name,digest in plan['frozen_hashes'].items():
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
old=load(R/'UDCT_v7_12_Preregistration_Jeans_Transition.py','v712_batch_trace')
proto=load(Path('/mnt/data/v713_b07_run/UDCT_v7_13_Six_Arm_Decision_Prototype.py'),'v713_batch_proto')
m=old.load_frozen();b=m.load_baseline();obj=b.DWARFS['Hydrus I']
with (R/'adaptive_brackets.csv').open() as f: targets=list(csv.DictReader(f))
assert len(targets)==24
laws={law.name:law for law in (b.BASE_LAW,)+b.PART_A_LAWS}
configs=[('default',b.make_grid('default')),('refined',b.make_grid('refined')),('validation',b.Grid(radial=1440,polar=96,azimuth=144,disk_radial=480,disk_azimuth=256,disk_height=48))]
# Cache the force for each law, ell, resolution, and inner radius across targets.
cache={};profiles={};results=[];t0=time.monotonic()
start=int(sys.argv[1]) if len(sys.argv)>1 else 2
stop=int(sys.argv[2]) if len(sys.argv)>2 else 24
for index in range(start,stop+1):
    target=targets[index-1]
    tid=f'B{index:02d}'; axis=target['axis'];law=target['law']; fixed=float(target['fixed_coordinate']);lo=float(target['lo']);hi=float(target['hi'])
    assert axis in ('beta','ell_pc') and law in laws
    endpoints=[lo,hi]; arms={p:{} for p in endpoints}; logs=[]
    for gridname,grid in configs:
        e,h=b.V706.galactic_field(obj,grid)[:2]
        for inner in (.002,.0005):
            for p in endpoints:
                ell=fixed if axis=='beta' else p
                beta=p if axis=='beta' else fixed
                cachekey=(law,ell,gridname,inner)
                if cachekey not in cache:
                    st=b.model_state(obj,'Tapered cusp',b.mesh('Tapered cusp',grid,rmin=inner),e,h,grid,laws[law],ell,0.)
                    _,force=b.V706.work_from_state(st)
                    _,ref=b.V706.aperture_jeans(st,force,obj.re_pc)
                    pressure,_,_=m.solve(st['r'],st['rho'],force,0.)
                    sigma=np.divide(pressure,st['rho'],out=np.zeros_like(pressure),where=st['rho']>1e-280)
                    vref2=float(np.interp(1.,st['r']/st['rh'],st['gn']))*st['rh']
                    gate=float(np.max(abs(sigma-ref))/vref2)
                    assert np.isfinite(gate) and gate<1e-10,(tid,cachekey,gate)
                    cache[cachekey]=(st,force,gate)
                st,force,gate=cache[cachekey]
                rec=m.summary(st['r'],st['rho'],force,beta,st['rh'],st['gn'])
                key=f'{gridname}|{inner:g}';vec=np.asarray(rec['common_sigma2_over_vref2'],dtype=float)
                assert vec.size==1200 and np.all(np.isfinite(vec))
                native=float(rec['min_sigma2_kms2']*1e6/rec['vref2_si'])
                arms[p][key]={'common':vec,'native_min':native,'gate':True}
                profiles[f'{tid}|{p:g}|{key}']=vec
                logs.append({'coordinate':p,'arm':key,'native_min':native,'common_min':float(vec.min()),'isotropic_gate':gate})
    endpoint_results={str(p):proto.decide(arms[p]) for p in endpoints}
    status=proto.bracket(*(endpoint_results[str(p)] for p in endpoints))
    results.append({'target':tid,'axis':axis,'law':law,'fixed_coordinate':fixed,'endpoints':endpoints,'results':endpoint_results,'bracket_status':status,'per_arm_logs':logs,'attempt_history':[{'iteration':0,'action':'initial endpoints only','decision':status,'reason':'Stop at initial unresolved numerical margin' if status=='unresolved_numerical_margin' else 'No further iteration in exploratory archival run'}]})
    print(tid,status,'elapsed',round(time.monotonic()-t0,1),flush=True)
npz=OUT/f'UDCT_v7_13_B{start:02d}_B{stop:02d}_Full_Common_Profiles.npz';np.savez_compressed(npz,**profiles)
report={'classification':'EXPLORATORY REPRODUCIBILITY TRACE; NOT CONFIRMATORY','frozen_hashes_verified':True,'targets':results,'profile_count':len(profiles),'profile_archive':npz.name,'profile_archive_sha256':hashlib.sha256(npz.read_bytes()).hexdigest(),'hessian':'NOT EVALUATED','limitations':['Prototype decision, not independently validated solver','3D total-potential Hessian not computed','No observational individual-star fit','Chronology of preregistration amendment not independently verified','Only initial endpoints are tested in this archive; prior midpoint histories are not reconstructed'],'elapsed_seconds':round(time.monotonic()-t0,2)}
out=OUT/f'UDCT_v7_13_B{start:02d}_B{stop:02d}_Full_Profile_Trace.json';out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('DONE',len(results),len(profiles),report['elapsed_seconds'],flush=True)

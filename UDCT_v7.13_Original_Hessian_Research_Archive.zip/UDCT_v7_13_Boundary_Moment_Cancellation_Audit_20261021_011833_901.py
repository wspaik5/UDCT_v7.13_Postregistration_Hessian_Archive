#!/usr/bin/env python3
"""Reproducible secondary audit of frozen exploratory source-localization results.
No new 3D solve and no preregistered confirmatory test.
"""
from pathlib import Path
import hashlib, json
p=Path(__file__).with_name('UDCT_v7_13_Source_Localization_Boundary_Audit.json')
raw=p.read_bytes(); src=json.loads(raw)
rows=[]
for x in src['results']:
    a=x['absolute_source_integral']; signed=x['signed_source_integral']
    assert a>0 and abs(signed)<=a*(1+1e-12)
    rows.append({
      'model':x['law'], 'box_side_rh':round(x['box_side_over_rh']),
      'signed_source_over_abs_source':signed/a,
      'opposing_sign_cancellation_fraction':1-abs(signed)/a,
      'outer_abs_source_fraction':x['outer_shell_abs_fraction'],
      'dipole_norm_over_abs_source_rh':x['dipole_moment_norm_over_abs_integral_rh'],
      'outer_rms_over_inner_rms':x['outer_shell_rms_to_inner_rms']})
by={(r['model'],r['box_side_rh']):r for r in rows}
comparisons=[]
for model in sorted(set(r['model'] for r in rows)):
    a,b=by[(model,6)],by[(model,8)]
    comparisons.append({'model':model,
      'outer_abs_fraction_6rh_to_8rh_ratio':b['outer_abs_source_fraction']/a['outer_abs_source_fraction'],
      'signed_over_abs_6rh':a['signed_source_over_abs_source'],
      'signed_over_abs_8rh':b['signed_source_over_abs_source'],
      'dipole_norm_ratio_8rh_over_6rh':b['dipole_norm_over_abs_source_rh']/a['dipole_norm_over_abs_source_rh']})
out={'status':'SECONDARY_DIAGNOSTIC_ONLY_NOT_PHYSICAL_BOUNDARY_VALIDATION',
     'input_file':p.name,'input_sha256':hashlib.sha256(raw).hexdigest(),
     'interpretation':'Signed source is strongly canceled by positive/negative contributions. A small signed integral does not imply negligible external potential, and dipole is not the full multipole expansion.',
     'limitations':['No exterior source computed','No new Poisson solve','No physically justified asymptotic boundary','No preregistered B01-B24 execution','No Jeans or observational validation'],
     'rows':rows,'comparisons':comparisons}
q=Path(__file__).with_suffix('.json');q.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(q),'rows':rows,'comparisons':comparisons},indent=2))

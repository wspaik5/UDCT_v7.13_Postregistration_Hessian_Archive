#!/usr/bin/env python3
"""Read-only readiness audit. Does NOT certify v7.13 scientific results."""
import json,hashlib,subprocess,sys,pathlib,collections
R=pathlib.Path(__file__).resolve().parent
P=R/'UDCT_v7_13_Confirmatory_Gate_Staging'
plan=json.loads((P/'preregistration_plan.json').read_text())
checks=[]
for name,digest in plan['frozen_hashes'].items():
 p=P/name
 checks.append({'file':name,'exists':p.exists(),'hash_matches':p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==digest})
selftests={}
for filename in ('UDCT_v7_13_Protocol_Audit.py','UDCT_v7_13_Preregistration_Preflight.py'):
 r=subprocess.run([sys.executable,str(P/filename),'--selftest'],capture_output=True,text=True,cwd=P)
 selftests[filename]={'passed':r.returncode==0,'output':(r.stdout+r.stderr).strip()}
r=subprocess.run([sys.executable,str(R/'v713_b07_run/UDCT_v7_13_Six_Arm_Decision_Prototype.py'),'--selftest'],capture_output=True,text=True)
selftests['Six_Arm_Decision_Prototype']={'passed':r.returncode==0,'output':(r.stdout+r.stderr).strip()}
rows=[]
for i in range(1,25):
 p=R/f'UDCT_v7_13_B{i:02d}_Six_Arm_Profile_Exploratory.json'
 if not p.exists(): rows.append({'id':f'B{i:02d}','present':False});continue
 d=json.loads(p.read_text());ends=d.get('endpoint_results',{})
 rows.append({'id':f'B{i:02d}','present':True,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'six_arms_executed_claim':d.get('six_arms_executed'),'status':d.get('bracket_status'),
 'endpoint_count':len(ends),'has_full_common_grid_profiles':all('common_profiles' in e for e in ends.values()),
 'has_3d_hessian':d.get('hessian_executed',False),'arm_records':len(d.get('arms',[])),
 'has_attempt_history':bool(d.get('attempt_history'))})
summary={'files_verified':sum(x['hash_matches'] for x in checks),'files_total':len(checks),
 'selftests_passed':sum(v['passed'] for v in selftests.values()),'selftests_total':len(selftests),
 'targets_present':sum(x['present'] for x in rows),
 'unresolved_targets':sum(x.get('status')=='unresolved_numerical_margin' for x in rows),
 'targets_with_saved_full_profiles':sum(x.get('has_full_common_grid_profiles',False) for x in rows),
 'targets_with_attempt_history':sum(x.get('has_attempt_history',False) for x in rows),
 'targets_with_3d_hessian':sum(x.get('has_3d_hessian',False) for x in rows)}
out={'classification':'READ_ONLY_REPRODUCIBILITY_READINESS_NOT_CONFIRMATORY','summary':summary,
 'frozen_inputs':checks,'selftests':selftests,'targets':rows,
 'cautions':['Archived summaries do not retain full common-grid profiles, so an independent recomputation of E/tau from these summaries alone is impossible.',
 'The exploratory prototype synthetic selftest is not an independent scientific solver validation.',
 'Public availability and amendment-before-execution chronology are not verified by this local audit.',
 'No new Jeans or 3D Hessian galaxy simulation is performed.']}
p=R/'UDCT_v7_13_Confirmatory_Readiness_Audit.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps(summary,indent=2));print('SAVED',p)

#!/usr/bin/env python3
"""Exploratory 3-D constitutive derivative diagnostic; NOT a solved field equation."""
import sys, json, hashlib, importlib.util
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/v713_hessian_stage')
P=ROOT/'UDCT_v7_10_Postregistration_run.py'
spec=importlib.util.spec_from_file_location('v710_source_diagnostic',P)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
# Quadratic manufactured Newtonian potential: constant non-isotropic Hessian.
# Inputs are dimensionless with physical gradient and Hessian magnitudes.
H=np.diag([1.1e-30,1.6e-30,2.3e-30])
g0=np.array([1.4e-11,-1.0e-11,0.7e-11])
x0=np.array([1.2e18,-0.8e18,0.4e18])
L=1.2*m.PC

def response(x,law,ell):
 g=g0+H@x
 nu,wh=m.gq_kernel(np.array(np.dot(g,g)),np.array(np.sum(H*H)),ell,law)
 return float(nu)*g, float(wh)*H

def diagnostic(h,law,ell):
 # div(nu grad psi) and double-div(wh Hess psi), independently approximated.
 e=np.eye(3); divflux=0.; doublediv=0.
 for i in range(3):
  ap=response(x0+h*e[i],law,ell)[0]; am=response(x0-h*e[i],law,ell)[0]
  divflux+=(ap[i]-am[i])/(2*h)
  for j in range(3):
   pp=response(x0+h*e[i]+h*e[j],law,ell)[1][i,j]
   pm=response(x0+h*e[i]-h*e[j],law,ell)[1][i,j]
   mp=response(x0-h*e[i]+h*e[j],law,ell)[1][i,j]
   mm=response(x0-h*e[i]-h*e[j],law,ell)[1][i,j]
   doublediv+=(pp-pm-mp+mm)/(4*h*h)
 return {'div_nu_grad_psi':divflux,'double_div_Pij':doublediv,'combined_formal_source':divflux-doublediv}

out={'classification':'EXPLORATORY MANUFACTURED-POTENTIAL SOURCE DIAGNOSTIC, NOT HYDRUS I FIELD SOLUTION',
 'frozen_source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),
 'equation_note':'The combined sign is a formal Euler-Lagrange candidate requiring independent sign, normalization and boundary-condition audit.',
 'Hessian_constant_SI':H.tolist(),'g0_SI':g0.tolist(),'x0_m':x0.tolist(),
 'models':{},'not_done':['No 3-D modified-gravity PDE solved','No boundary conditions implemented','No Hydrus I Jeans or stellar data fit','No B01-B24 modified Hessian test']}
for name in ('A-Qs','A-Qd'):
 law=next(l for l in m.PART_A_LAWS if l.name==name)
 vals=[]
 for frac in (.08,.04,.02,.01):
  h=frac*L; vals.append({'step_pc':h/m.PC,**diagnostic(h,law,L)})
 out['models'][name]={'samples':vals,'relative_difference_last_two':{k:abs(vals[-1][k]-vals[-2][k])/max(abs(vals[-1][k]),1e-80) for k in ('div_nu_grad_psi','double_div_Pij','combined_formal_source')}}
# QUMOND control: ell=None implies wh=0 exactly.
law=next(l for l in m.PART_A_LAWS if l.name=='A-Qs')
out['QUMOND_control']={'Pij_zero':bool(np.all(response(x0,law,None)[1]==0)), 'sample':diagnostic(.01*L,law,None)}
assert out['QUMOND_control']['Pij_zero']
assert all(np.isfinite(s[k]) for v in out['models'].values() for s in v['samples'] for k in ('div_nu_grad_psi','double_div_Pij','combined_formal_source'))
path=Path('/mnt/data/UDCT_v7_13_Constitutive_3D_Source_Prototype.json')
path.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'models':{k:v['relative_difference_last_two'] for k,v in out['models'].items()},'QUMOND_control':out['QUMOND_control'],'output':str(path)},indent=2))

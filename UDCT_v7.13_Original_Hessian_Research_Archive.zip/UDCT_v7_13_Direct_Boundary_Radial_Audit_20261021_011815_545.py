#!/usr/bin/env python3
"""Exploratory same-coordinate radial acceleration under zero vs in-box Green boundary."""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.signal import fftconvolve
R=Path('/mnt/data')
source=R/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
s=source.read_text();s=s[:s.index("out={'status'")];s=s.replace(' pot=solve(rhs,h)', ' return rhs,h')
ns={'__file__':str(source)};exec(compile(s,str(source),'exec'),ns)
m=ns['m'];rh=ns['rh']
def solve_dirichlet(rhs,h,faces):
 v=rhs.copy();hh=h*h
 for ax,(low,high) in enumerate(faces):
  if ax==0:v[0,:,:]-=low/hh;v[-1,:,:]-=high/hh
  elif ax==1:v[:,0,:]-=low/hh;v[:,-1,:]-=high/hh
  else:v[:,:,0]-=low/hh;v[:,:,-1]-=high/hh
 return ns['solve'](v,h)
def calc(lawname,side,n):
 ns['run'].__globals__['L']=side*rh
 law=next(z for z in m.PART_A_LAWS if z.name==lawname)
 rhs,h=ns['run'](n,law,10.)
 N=n+2;padded=np.pad(rhs,1)
 offs=np.arange(-(N-1),N,dtype=float)*h
 d2=offs[:,None,None]**2+offs[None,:,None]**2+offs[None,None,:]**2
 kernel=np.zeros_like(d2);mask=d2>0;kernel[mask]=-h**3/(4*np.pi*np.sqrt(d2[mask]))
 full=fftconvolve(padded,kernel,mode='same')
 faces=[(np.take(full,0,axis=ax)[1:-1,1:-1],np.take(full,-1,axis=ax)[1:-1,1:-1]) for ax in range(3)]
 phi_direct=solve_dirichlet(rhs,h,faces);phi_zero=ns['solve'](rhs,h)
 mid=n//2;rows=[]
 for r in (0.5,1.,2.):
  ix=mid+round(r*rh/h)
  def grad(phi):return np.array([(phi[ix+1,mid,mid]-phi[ix-1,mid,mid]),(phi[ix,mid+1,mid]-phi[ix,mid-1,mid]),(phi[ix,mid,mid+1]-phi[ix,mid,mid-1])])/(2*h*m.A0)
  gz=grad(phi_zero);gd=grad(phi_direct)
  rows.append({'radius_rh':r,'zero_gradient_over_a0':gz.tolist(),'direct_gradient_over_a0':gd.tolist(),'vector_difference_over_a0':float(np.linalg.norm(gd-gz)),'relative_vector_difference_pct':float(100*np.linalg.norm(gd-gz)/max(np.linalg.norm(gd),1e-300))})
 return {'law':lawname,'box_side_rh':side,'n':n,'h_over_rh':h/rh,'radial':rows}
results=[]
for law in ('A-Qs','A-f1/2'):
 for side,n in ((6,47),(8,63)):
  x=calc(law,side,n);results.append(x)
  print(law,side,[(z['radius_rh'],round(z['relative_vector_difference_pct'],5)) for z in x['radial']],flush=True)
out={'status':'EXPLORATORY_TRUNCATED_SOURCE_ONLY','note':'Direct Green boundary integrates ONLY interior source, no outside-box source, not physical far-field and not B01-B24 prereg test','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'results':results}
p=R/'UDCT_v7_13_Direct_Boundary_Radial_Audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print(p)

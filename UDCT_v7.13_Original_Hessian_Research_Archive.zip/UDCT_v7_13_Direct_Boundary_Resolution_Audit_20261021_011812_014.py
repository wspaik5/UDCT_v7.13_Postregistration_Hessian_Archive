#!/usr/bin/env python3
"""Exploratory fixed-box resolution audit with in-box Green boundary (not prereg)."""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.signal import fftconvolve
R=Path('/mnt/data')
source=R/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
s=source.read_text();s=s[:s.index("out={'status'")];s=s.replace(' pot=solve(rhs,h)', ' return rhs,h')
ns={'__file__':str(source)};exec(compile(s,str(source),'exec'),ns)
m=ns['m'];rh=ns['rh'];ns['run'].__globals__['L']=6*rh

def solve_bc(rhs,h):
 n=rhs.shape[0];N=n+2
 padded=np.pad(rhs,1)
 offs=np.arange(-(N-1),N,dtype=float)*h
 d2=offs[:,None,None]**2+offs[None,:,None]**2+offs[None,None,:]**2
 ker=np.zeros_like(d2);mask=d2>0;ker[mask]=-h**3/(4*np.pi*np.sqrt(d2[mask]))
 full=fftconvolve(padded,ker,mode='same')
 rhs_bc=rhs.copy();hh=h*h
 for ax in range(3):
  low=np.take(full,0,axis=ax)[1:-1,1:-1];high=np.take(full,-1,axis=ax)[1:-1,1:-1]
  if ax==0:rhs_bc[0,:,:]-=low/hh;rhs_bc[-1,:,:]-=high/hh
  elif ax==1:rhs_bc[:,0,:]-=low/hh;rhs_bc[:,-1,:]-=high/hh
  else:rhs_bc[:,:,0]-=low/hh;rhs_bc[:,:,-1]-=high/hh
 return ns['solve'](rhs_bc,h)

rows=[]
for lawname in ('A-Qs','A-f1/2'):
 law=next(z for z in m.PART_A_LAWS if z.name==lawname)
 for n in (23,35,47):
  rhs,h=ns['run'](n,law,10.)
  phi=solve_bc(rhs,h);mid=n//2
  results=[]
  for r in (0.5,1.,2.):
   ix=mid+round(r*rh/h)
   grad=np.array([phi[ix+1,mid,mid]-phi[ix-1,mid,mid],phi[ix,mid+1,mid]-phi[ix,mid-1,mid],phi[ix,mid,mid+1]-phi[ix,mid,mid-1]])/(2*h*m.A0)
   results.append({'radius_rh':r,'gradient_over_a0':grad.tolist(),'gradient_norm_over_a0':float(np.linalg.norm(grad))})
  rows.append({'law':lawname,'n':n,'box_side_rh':6,'spacing_rh':float(h/rh),'radial':results})
  print(lawname,n,[(a['radius_rh'],round(a['gradient_norm_over_a0'],9)) for a in results],flush=True)
comparisons=[]
for lawname in ('A-Qs','A-f1/2'):
 a=[r for r in rows if r['law']==lawname]
 for i,r in enumerate((0.5,1.,2.)):
  u=np.array(a[1]['radial'][i]['gradient_over_a0']);v=np.array(a[2]['radial'][i]['gradient_over_a0'])
  comparisons.append({'law':lawname,'radius_rh':r,'vector_change_35_to_47_pct':float(100*np.linalg.norm(v-u)/np.linalg.norm(v))})
out={'status':'EXPLORATORY_IN_BOX_SOURCE_ONLY_NOT_PREREG','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'boundary':'direct Green integral of IN-BOX sampled source using cell-center point masses; outside-box source omitted','limitations':['No physical far-field boundary','No observational fit','No Jeans or B01-B24 validation','Finite differences and Green quadrature not jointly converged'],'rows':rows,'comparisons':comparisons}
p=R/'UDCT_v7_13_Direct_Boundary_Resolution_Audit.json';p.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print('SAVED',p)

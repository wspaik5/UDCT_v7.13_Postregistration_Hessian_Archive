#!/usr/bin/env python3
"""Exploratory: compare direct in-box source boundary to multipoles/zero boundary.
Outside-box source omitted; not a physical completion or preregistered B01-B24 test.
"""
import json,hashlib
from pathlib import Path
import numpy as np
from scipy.signal import fftconvolve
R=Path('/mnt/data')
source=R/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
s=source.read_text();s=s[:s.index("out={'status'")];s=s.replace(' pot=solve(rhs,h)', ' return rhs,h')
ns={'__file__':str(source)};exec(compile(s,str(source),'exec'),ns)
m=ns['m'];rh=ns['rh']

def solve_dirichlet(rhs,h,faces):
 v=rhs.copy(); hh=h*h
 for axis,(low,high) in enumerate(faces):
  if axis==0:v[0,:,:]-=low/hh;v[-1,:,:]-=high/hh
  elif axis==1:v[:,0,:]-=low/hh;v[:,-1,:]-=high/hh
  else:v[:,:,0]-=low/hh;v[:,:,-1]-=high/hh
 return ns['solve'](v,h)

def calculate(lawname,side,n):
 ns['run'].__globals__['L']=side*rh
 law=next(z for z in m.PART_A_LAWS if z.name==lawname)
 rhs,h=ns['run'](n,law,10.)
 # All interior cells have a point-mass quadrature weight rhs*h^3.
 # FFT convolution evaluates -sum_j rhs_j h^3/(4*pi*|x_i-x_j|) at cube face nodes.
 N=n+2; padded=np.pad(rhs,1)
 offs=np.arange(-(N-1),N,dtype=float)*h
 d2=offs[:,None,None]**2+offs[None,:,None]**2+offs[None,None,:]**2
 kernel=np.zeros_like(d2);mask=d2>0;kernel[mask]=-h**3/(4*np.pi*np.sqrt(d2[mask]))
 phi_full=fftconvolve(padded,kernel,mode='same')
 direct=[(np.take(phi_full,0,axis=ax)[1:-1,1:-1],np.take(phi_full,-1,axis=ax)[1:-1,1:-1]) for ax in range(3)]
 # In-box multipole approximations, computed at the same boundary nodes.
 coords=(np.arange(n)-(n-1)/2)*h
 X=np.meshgrid(coords,coords,coords,indexing='ij');flat=np.stack([v.ravel() for v in X],axis=1)
 w=rhs.ravel()*h**3;M=w.sum();D=np.einsum('n,ni->i',w,flat)
 rr=(flat**2).sum(axis=1)
 Q=3*np.einsum('n,ni,nj->ij',w,flat,flat)-np.eye(3)*np.dot(w,rr)
 def multipole(pos,degree):
  rad=np.linalg.norm(pos,axis=-1);v=-M/(4*np.pi*rad)
  if degree>=1:v-=np.einsum('...i,i->...',pos,D)/(4*np.pi*rad**3)
  if degree>=2:v-=np.einsum('...i,ij,...j->...',pos,Q,pos)/(8*np.pi*rad**5)
  return v
 u,v=np.meshgrid(coords,coords,indexing='ij')
 def faces_for(degree):
  faces=[]
  for ax in range(3):
   pair=[]
   for sign in (-1,1):
    pos=np.empty((n,n,3));pos[...,ax]=sign*side*rh/2
    other=[j for j in range(3) if j!=ax]
    pos[...,other[0]]=u;pos[...,other[1]]=v
    pair.append(multipole(pos,degree))
   faces.append(tuple(pair))
  return faces
 zeros=[(np.zeros((n,n)),np.zeros((n,n))) for _ in range(3)]
 face_modes={'zero':zeros,'monopole':faces_for(0),'dipole':faces_for(1),'quadrupole':faces_for(2),'direct_inbox':direct}
 i=n//2;ix=i+round(rh/h)
 result={};dvec=np.concatenate([np.ravel(z) for pair in direct for z in pair]);scale=np.sqrt(np.mean(dvec*dvec))
 for mode,faces in face_modes.items():
  phi=solve_dirichlet(rhs,h,faces)
  gx=(phi[ix+1,i,i]-phi[ix-1,i,i])/(2*h*m.A0)
  result[mode]={'gx_at_rh_over_a0':float(gx),'phi_center_over_a0rh':float(phi[i,i,i]/(m.A0*rh))}
  if mode!='direct_inbox':
   approx=np.concatenate([np.ravel(z) for pair in faces for z in pair])
   result[mode]['face_rms_difference_over_direct_face_rms']=float(np.sqrt(np.mean((approx-dvec)**2))/scale)
 return {'law':lawname,'side_rh':side,'n':n,'h_over_rh':float(h/rh),'direct_boundary_rms_over_a0rh':float(scale/(m.A0*rh)),'results':result}

out={'status':'EXPLORATORY_INBOX_DIRECT_SOURCE_BOUNDARY','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'description':'Compare free-space Green function quadrature of TRUNCATED IN-BOX Poisson source against multipole and zero face boundary values','limitations':['Outside-box source omitted','Galactic Taylor field invalid arbitrarily far','Direct convolution uses point-cell quadrature, not exact continuum volume integration','No validated physical exterior boundary','Not a Jeans solution or B01-B24 prereg test'],'rows':[]}
for law in ('A-Qs','A-f1/2'):
 for side,n in ((6,47),(8,63)):
  row=calculate(law,side,n);out['rows'].append(row)
  print(law,side,{k:round(v['gx_at_rh_over_a0'],10) for k,v in row['results'].items()},flush=True)
p=R/'UDCT_v7_13_Direct_Source_Boundary_Audit.json';p.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print('SAVED',p)

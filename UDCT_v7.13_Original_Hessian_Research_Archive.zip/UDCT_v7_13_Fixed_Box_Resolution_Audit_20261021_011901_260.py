#!/usr/bin/env python3
"""Exploratory fixed-box resolution audit, NOT physical boundary validation."""
import json, hashlib
from pathlib import Path
P=Path('/mnt/data/UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py')
s=P.read_text(); s=s[:s.index("out={'status'")]
ns={'__file__':str(P)}
exec(compile(s,str(P),'exec'),ns)
rows=[]
for lawname in ('A-Qs','A-f1/2'):
 law=next(x for x in ns['m'].PART_A_LAWS if x.name==lawname)
 for n in (23,35,47):
  r=ns['run'](n,law,10.)
  rows.append(r)
  print(lawname,n,r['center_delta_phi_over_a0_rh'],r['center_delta_acceleration_over_a0'],flush=True)
summary={}
for lawname in ('A-Qs','A-f1/2'):
 v=[x for x in rows if x['law']==lawname]
 summary[lawname]={"phi_relative_change_35_to_47":(v[2]['center_delta_phi_over_a0_rh']-v[1]['center_delta_phi_over_a0_rh'])/abs(v[1]['center_delta_phi_over_a0_rh']),"acc_relative_change_35_to_47":(v[2]['center_delta_acceleration_over_a0']-v[1]['center_delta_acceleration_over_a0'])/max(abs(v[1]['center_delta_acceleration_over_a0']),1e-30)}
out={'status':'EXPLORATORY_NOT_PREREG_NOT_PHYSICAL_BOUNDARY','method':'fixed cube side 6 rh; n=23,35,47, same finite zero Dirichlet; center exactly grid node','source_solver_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'results':rows,'summary':summary,'caveat':'Grid refinement does not validate finite-box boundary; central acceleration is not a stellar observable.'}
q=Path('/mnt/data/UDCT_v7_13_Fixed_Box_Resolution_Audit.json');q.write_text(json.dumps(out,indent=2)+'\n')
print('saved',q)

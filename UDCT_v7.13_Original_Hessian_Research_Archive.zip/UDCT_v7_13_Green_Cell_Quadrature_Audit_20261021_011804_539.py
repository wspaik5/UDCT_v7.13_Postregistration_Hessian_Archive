#!/usr/bin/env python3
"""Standalone local Green kernel cell quadrature audit; NOT a full Hydrus solver.
Compare midpoint approximation of 1/r over a cubic source cell against tensor Gauss quadrature.
Boundary nodes of existing solver are >= one grid spacing from source-cell centers.
"""
import json, hashlib
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss

def cube_kernel(distance_in_h, order):
    x,w=leggauss(order)
    x=x/2; w=w/2
    xx,yy,zz=np.meshgrid(x,x,x,indexing='ij')
    ww=w[:,None,None]*w[None,:,None]*w[None,None,:]
    r=np.sqrt((distance_in_h[0]-xx)**2+(distance_in_h[1]-yy)**2+(distance_in_h[2]-zz)**2)
    return float(np.sum(ww/r))

cases={'face_nearest':(1.,0.,0.),'face_diagonal':(1.,1.,0.),'face_3d_diagonal':(1.,1.,1.),'face_2h':(2.,0.,0.),'face_4h':(4.,0.,0.),'face_8h':(8.,0.,0.)}
rows=[]
for name,coords in cases.items():
    vals={str(n):cube_kernel(coords,n) for n in (2,4,8,12,20)}
    point=1/np.linalg.norm(coords)
    ref=vals['20']
    row={'geometry':name,'center_separation_in_cell_widths':list(coords),'midpoint_kernel':float(point),'gauss_20_reference':ref,'midpoint_relative_error_pct':float(100*(point/ref-1)),'gauss_8_vs_20_pct':float(100*(vals['8']/ref-1)),'gauss_12_vs_20_pct':float(100*(vals['12']/ref-1))}
    rows.append(row)
    print(f"{name:18s} midpoint error {row['midpoint_relative_error_pct']:+.6f}%  gauss12-vs20 {row['gauss_12_vs_20_pct']:+.3g}%")
source=Path('/mnt/data/UDCT_v7_13_Direct_Source_Boundary_Audit.py')
out={'status':'LOCAL_GREEN_KERNEL_QUADRATURE_AUDIT_ONLY','reference_script_sha256':hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None,'description':'Compare point-cell Green kernel against numerical cube-integrated Green kernel at representative cell-center separations, normalized by cell width. This isolates geometric quadrature error, not total boundary or acceleration error.','rows':rows,'limitations':['No full Hydrus source convolution recomputed','Cell source variation within each cube not included','No source outside simulation box','Does not certify physical boundary or Jeans sign']}
path=Path('/mnt/data/UDCT_v7_13_Green_Cell_Quadrature_Audit.json')
path.write_text(json.dumps(out,indent=2)+'\n')
print('SAVED',path)

#!/usr/bin/env python3
"""Reproduce equivalent Newtonian densities of the manufactured quadratic field.
This is not a Hydrus I observation, simulation, or GQUMOND inference.
"""
import json, math
from pathlib import Path
G_SI=6.67430e-11
PC_M=3.085677581491367e16
MSUN_KG=1.98847e30
BASE_H_DIAG_S2=[1.1e-30,1.6e-30,2.3e-30]

def main():
    rows=[]
    for factor in (1,10,100):
        trace=sum(BASE_H_DIAG_S2)*factor
        rho_si=trace/(4*math.pi*G_SI)
        rho_msun_pc3=rho_si*PC_M**3/MSUN_KG
        rows.append({'hessian_multiplier':factor,'trace_H_s_minus_2':trace,
                     'rho_equivalent_kg_m_minus_3':rho_si,
                     'rho_equivalent_Msun_pc_minus_3':rho_msun_pc3})
    result={'title':'UDCT v7.13 manufactured Hessian equivalent-density audit',
            'scope':'Algebraic Newtonian consistency check only; NOT measured Hydrus I density',
            'source_field':'H=diag(1.1,1.6,2.3) * 1e-30 s^-2 * multiplier',
            'equation':'rho_eq=trace(H)/(4*pi*G)',
            'constants':{'G_m3_kg_minus1_s_minus2':G_SI,'pc_m':PC_M,'Msun_kg':MSUN_KG},
            'rows':rows}
    target=Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for r in rows:print(f"{r['hessian_multiplier']:3d}x: {r['rho_equivalent_Msun_pc_minus_3']:.8f} Msun/pc^3")
    print('JSON:',target)
if __name__=='__main__':main()

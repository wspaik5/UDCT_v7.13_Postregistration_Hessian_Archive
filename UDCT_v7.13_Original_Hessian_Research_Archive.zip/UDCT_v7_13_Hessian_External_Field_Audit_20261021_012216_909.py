#!/usr/bin/env python3
"""Exploratory REAL Hydrus I external Newtonian tidal Hessian audit.
NOT a total modified-gravity Hessian, NOT GQUMOND validation.
"""
import hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/v713_hessian_stage')
P=Path('/mnt/data/UDCT_v7_13_Preregistration_Updated/preregistration_plan.json')
plan=json.loads(P.read_text())
checks={}
for name,sha in plan['frozen_hashes'].items():
    file=ROOT/name
    if not file.exists(): file=Path('/mnt/data/v713_b07_run')/name
    checks[name]=file.exists() and hashlib.sha256(file.read_bytes()).hexdigest()==sha
assert all(checks.values()),checks
spec=importlib.util.spec_from_file_location('frozen_v706',ROOT/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
obj=m.DWARFS['Hydrus I']
# Grid radial/polar/azimuth not used by galactic_field; only disk quadrature changes.
grids=[('default',m.Grid(disk_radial=120,disk_azimuth=64,disk_height=12)),('refined',m.Grid(disk_radial=240,disk_azimuth=128,disk_height=24))]
records=[]
for name,g in grids:
    e,h,mass=m.galactic_field(obj,g)
    eig=np.linalg.eigvalsh(h)
    records.append({'grid':name,'gradient_m_s2':e.tolist(),'hessian_s_minus2':h.tolist(),'eigenvalues_s_minus2':eig.tolist(),'trace_s_minus2':float(np.trace(h)),'frobenius_s_minus2':float(np.linalg.norm(h)),'symmetry_max_s_minus2':float(np.max(abs(h-h.T))),'mass_integrated_msun':float(mass)})
    print(name,'eigenvalues s^-2',eig,'trace',np.trace(h),flush=True)
a=np.array(records[0]['hessian_s_minus2']);b=np.array(records[1]['hessian_s_minus2'])
report={'scope':'EXPLORATORY Hydrus I Milky Way Newtonian EXTERNAL Hessian ONLY',
'full_modified_total_potential_hessian_executed':False,'B01_B24_model_hessian_executed':False,
'not_equivalent_to':'Hessian of Phi_total for BASE/A-f2/A-Qs/A-Qd; not a GQUMOND field solve',
'source_hashes_verified':checks,'hydrus_galactocentric_kpc':m.galactocentric_position(obj).tolist(),
'grid_results':records,'refined_minus_default_max_abs_s_minus2':float(np.max(abs(b-a))),
'refined_minus_default_relative_frobenius':float(np.linalg.norm(b-a)/np.linalg.norm(b)),
'limitations':'Only two disk quadrature grids; no third-grid convergence proof; no full 3D modified potential; cannot use preregistered Hessian convergence gate on this tensor.',
'next_step':'Implement model-consistent 3D total potential and independent checks; then apply three preregistered spatial steps and tensor convergence gate.'}
out=Path('/mnt/data/UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json')
out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('relative discrepancy',report['refined_minus_default_relative_frobenius']);print('SAVED',out)

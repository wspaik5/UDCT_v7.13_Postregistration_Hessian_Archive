#!/usr/bin/env python3
"""Exploratory grid convergence of factor-correction sensitivity; not Hydrus I."""
import json,zipfile,hashlib,importlib.util,sys
from pathlib import Path
import numpy as np
from scipy.fft import dstn,idstn
Z=Path('/mnt/data/UDCT_v7_13_Preregistration_Complete_Updated.zip')
with zipfile.ZipFile(Z) as z:
 plan=json.loads(z.read('preregistration_plan.json'))
 for name,sha in plan['frozen_hashes'].items():
  assert hashlib.sha256(z.read(name)).hexdigest()==sha,name
 src=z.read('UDCT_v7_10_Postregistration_run.py');base=z.read('UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py')
R=Path('/mnt/data/v713_grid_convergence');R.mkdir(exist_ok=True)
P=R/'UDCT_v7_10_Postregistration_run.py';P.write_bytes(src)
(R/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py').write_bytes(base)
spec=importlib.util.spec_from_file_location('v710_grid_audit',P)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
L=1.2*m.PC

def solve(rhs,h):
 n=rhs.shape[0];k=np.arange(1,n+1);ev=2*(np.cos(np.pi*k/(n+1))-1)/h**2
 return idstn(dstn(rhs,type=1,norm='ortho')/(ev[:,None,None]+ev[None,:,None]+ev[None,None,:]),type=1,norm='ortho')

def run(n,law,ell_pc,hfactor):
 h=L/(n+1);q=np.arange(-1,n+3)*h-L/2
 x,y,z=np.meshgrid(q,q,q,indexing='ij')
 H=np.array([1.1,1.6,2.3])*1e-30*hfactor
 g0=np.array([1.4,-1.0,.7])*1e-11
 gx=g0[0]+H[0]*x;gy=g0[1]+H[1]*y;gz=g0[2]+H[2]*z
 g2=gx*gx+gy*gy+gz*gz
 nu,wh=m.gq_kernel(g2,np.sum(H*H),ell_pc*m.PC,law)
 sl=(slice(2,-2),)*3
 div=np.zeros((n,n,n));dd=np.zeros_like(div)
 for i,gi in enumerate((gx,gy,gz)):
  flux=nu*gi;p=wh*H[i]
  sp=list(sl);sm=list(sl);sp[i]=slice(3,-1);sm[i]=slice(1,-3)
  div+=(flux[tuple(sp)]-flux[tuple(sm)])/(2*h)
  dd+=(p[tuple(sp)]-2*p[sl]+p[tuple(sm)])/h**2
 correct=div-.5*dd;old=div-dd
 pc=solve(correct,h);po=solve(old,h)
 result={'model':law.name,'n':n,'h_pc':h/m.PC,'ell_pc':ell_pc,'hessian_multiplier':hfactor,
 'relative_potential_difference':float(np.linalg.norm(po-pc)/np.linalg.norm(pc)),
 'relative_source_difference':float(np.linalg.norm(old-correct)/np.linalg.norm(correct)),
 'center_corrected_phi_over_a0L':float(pc[n//2,n//2,n//2]/(m.A0*L)),
 'center_old_phi_over_a0L':float(po[n//2,n//2,n//2]/(m.A0*L)),
 'dd_div_ratio':float(np.linalg.norm(dd)/np.linalg.norm(div))}
 return result

rows=[]
for model in ('A-Qs','A-Qd'):
 law=next(v for v in m.PART_A_LAWS if v.name==model)
 for n in (24,48,96):
  r=run(n,law,10.0,100)
  rows.append(r)
  print(model,n,'relative potential difference',r['relative_potential_difference'],'center',r['center_corrected_phi_over_a0L'],flush=True)
summary={}
for model in ('A-Qs','A-Qd'):
 a=[r for r in rows if r['model']==model]
 d=[r['relative_potential_difference'] for r in a]
 summary[model]={'percent_potential_difference_by_grid':[100*x for x in d],
 'relative_change_48_to_96':abs(d[2]-d[1])/abs(d[2]),
 'relative_change_24_to_48':abs(d[1]-d[0])/abs(d[1]),
 'monotone_grid_sensitivity':bool(d[0]<d[1]<d[2] or d[0]>d[1]>d[2])}
report={'classification':'EXPLORATORY manufactured quadratic field; not Hydrus I','frozen_source_integrity':'8/8 SHA256 passed',
 'source_equations':{'corrected':'div(nu grad psi)-0.5 divdiv(wh Hess psi)','old':'div(nu grad psi)-divdiv(wh Hess psi)'},
 'boundary':'zero Dirichlet artificial cube 1.2 pc','conditions':'Hessian x100, ell 10 pc, identical physical cube across grids',
 'rows':rows,'summary':summary,'limitations':['No analytic reference solution for constitutive potential','Only grid sensitivity, not proof of physical correctness','No isolated boundary or Hydrus I input','No B01-B24 rerun']}
out=Path('/mnt/data/UDCT_v7_13_Hessian_Factor_Grid_Convergence.json');out.write_text(json.dumps(report,indent=2)+'\n')
print('SAVED',out)

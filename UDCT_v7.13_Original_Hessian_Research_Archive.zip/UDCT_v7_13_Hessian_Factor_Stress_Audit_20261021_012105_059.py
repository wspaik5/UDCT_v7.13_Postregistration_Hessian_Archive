#!/usr/bin/env python3
"""Exploratory Hessian-factor stress test; manufactured 3D quadratic Newtonian field, not Hydrus I."""
import zipfile,hashlib,json,importlib.util,sys
from pathlib import Path
import numpy as np
from scipy.fft import dstn,idstn
Z=Path('/mnt/data/UDCT_v7_13_Preregistration_Complete_Updated.zip')
with zipfile.ZipFile(Z) as z:
 plan=json.loads(z.read('preregistration_plan.json'))
 for name,sha in plan['frozen_hashes'].items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
 source=z.read('UDCT_v7_10_Postregistration_run.py')
 v706=z.read('UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py')
P=Path('/mnt/data/v713_action_audit/UDCT_v7_10_Postregistration_run.py');P.parent.mkdir(exist_ok=True);P.write_bytes(source);(P.parent/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py').write_bytes(v706)
spec=importlib.util.spec_from_file_location('v710_stress',P);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
def solve(rhs,h):
 n=rhs.shape[0];k=np.arange(1,n+1);v=2*(np.cos(np.pi*k/(n+1))-1)/h**2
 return idstn(dstn(rhs,type=1,norm='ortho')/(v[:,None,None]+v[None,:,None]+v[None,None,:]),type=1,norm='ortho')
def test(n,law,ell_pc,Hfactor):
 L=1.2*m.PC;h=L/(n+1);q=(np.arange(-1,n+3)*h-L/2)
 x,y,z=np.meshgrid(q,q,q,indexing='ij')
 H=np.diag(np.array([1.1,1.6,2.3])*1e-30*Hfactor);g0=np.array([1.4,-1.,.7])*1e-11
 g=np.stack([g0[0]+H[0,0]*x,g0[1]+H[1,1]*y,g0[2]+H[2,2]*z]);g2=np.sum(g*g,axis=0)
 nu,wh=m.gq_kernel(g2,np.array(np.sum(H*H)),ell_pc*m.PC,law)
 flux=nu[None,...]*g;sl=(slice(2,-2),)*3
 div=np.zeros((n,n,n));dd=np.zeros_like(div)
 for i in range(3):
  a=flux[i];p=wh*H[i,i];s1=list(sl);s2=list(sl);s1[i]=slice(3,-1);s2[i]=slice(1,-3)
  div+=(a[tuple(s1)]-a[tuple(s2)])/(2*h)
  dd+=(p[tuple(s1)]-2*p[sl]+p[tuple(s2)])/h**2
 corrected=div-.5*dd;old=div-dd
 phic=solve(corrected,h);phio=solve(old,h)
 return {'n':n,'law':law.name,'ell_pc':ell_pc,'hessian_multiplier':Hfactor,'dd_to_div_norm':float(np.linalg.norm(dd)/max(np.linalg.norm(div),1e-90)),'source_change_relative':float(np.linalg.norm(old-corrected)/max(np.linalg.norm(corrected),1e-90)),'potential_change_relative':float(np.linalg.norm(phio-phic)/max(np.linalg.norm(phic),1e-90)),'corrected_center_phi_normalized':float(phic[n//2,n//2,n//2]/(m.A0*L)),'old_center_phi_normalized':float(phio[n//2,n//2,n//2]/(m.A0*L))}
rows=[]
for lawname in ('A-Qs','A-Qd'):
 law=next(v for v in m.PART_A_LAWS if v.name==lawname)
 for hf in (1,10,100):
  for ell in (0.1,1.,10.):
   rows.append(test(24,law,ell,hf))
for row in rows:print(row['law'],row['hessian_multiplier'],row['ell_pc'],'source difference',round(row['source_change_relative'],6),'potential difference',round(row['potential_change_relative'],6))
report={'status':'EXPLORATORY manufactured-field sensitivity only; not Hydrus I or B01-B24','source_integrity':'8 of 8 frozen SHA256 verified','equations':{'corrected':'div(nu grad psi)-0.5 divdiv(wh H)','superseded':'div(nu grad psi)-divdiv(wh H)'},'boundary':'zero Dirichlet on artificial cube','rows':rows}
out=Path('/mnt/data/UDCT_v7_13_Hessian_Factor_Stress_Audit.json');out.write_text(json.dumps(report,indent=2)+'\n');print('SAVED',out)

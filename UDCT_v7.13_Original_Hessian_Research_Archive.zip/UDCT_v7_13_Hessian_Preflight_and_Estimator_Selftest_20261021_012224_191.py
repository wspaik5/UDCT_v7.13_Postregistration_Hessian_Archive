#!/usr/bin/env python3
"""Non-confirmatory preflight: frozen-source audit and synthetic 3-D Hessian estimator tests.
Does NOT calculate a Hydrus I total-potential Hessian or any B01-B24 Hessian outcome.
"""
from pathlib import Path
import hashlib, json, ast
import numpy as np
ROOT=Path('/mnt/data/v713_b07_run')
PLAN=json.loads((ROOT/'preregistration_plan.json').read_text())
verified={name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in PLAN['frozen_hashes'].items()}
assert all(verified.values())
cp=PLAN['complete_protocol']
steps=cp['hessian_steps_rh']
assert steps==[0.02,0.01,0.005]
# Generic central-difference tensor, not a galaxy solver.
def hessian(phi,x,h):
    x=np.array(x,dtype=float); out=np.zeros((3,3)); f0=phi(x)
    for i in range(3):
        ei=np.eye(3)[i]*h
        out[i,i]=(phi(x+ei)-2*f0+phi(x-ei))/h**2
        for j in range(i):
            ej=np.eye(3)[j]*h
            out[i,j]=out[j,i]=(phi(x+ei+ej)-phi(x+ei-ej)-phi(x-ei+ej)+phi(x-ei-ej))/(4*h*h)
    return out
A=np.array([[2.,0.3,-0.2],[0.3,-1.,0.4],[-0.2,0.4,3.]])
x=np.array([0.1,-0.2,0.3]); rh=1.
quad=lambda y: 0.5*y@A@y + np.array([0.4,0.1,-0.5])@y+0.7
quad_errors=[float(np.max(abs(hessian(quad,x,h*rh)-A))) for h in steps]
assert max(quad_errors)<1e-10
# Nonquadratic test has nonzero finite-difference truncation error; verify order.
quart=lambda y: 0.5*y@A@y + 0.6*y[0]**4+0.4*y[1]**4+0.2*y[2]**4
exact=A+np.diag([7.2*x[0]**2,4.8*x[1]**2,2.4*x[2]**2])
quart_errors=[float(np.max(abs(hessian(quart,x,h)-exact))) for h in steps]
assert quart_errors[0]>quart_errors[1]>quart_errors[2]
# Static source API check: no function returns Phi_total(x,y,z) for full modified gravity.
modules={}
for name in ['UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py','UDCT_v7_10_Postregistration_run.py','UDCT_v7_12_Preregistration_Jeans_Transition.py']:
    tree=ast.parse((ROOT/name).read_text()); modules[name]=[n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
report={
 'status':'PRELIMINARY PREFLIGHT ONLY — NOT GALAXY HESSIAN EXECUTION',
 'frozen_sha256_verified':all(verified.values()),'frozen_hash_checks':verified,
 'hessian_steps_rh':steps,
 'synthetic_quadratic_max_component_errors':quad_errors,
 'synthetic_quartic_max_component_errors':quart_errors,
 'synthetic_estimator_selftest':'PASS',
 'source_functions':modules,
 'source_observation':'Existing galactic_field returns the Milky Way Newtonian external gradient and tidal Hessian. Existing model_state uses angular/radial reductions, and does not expose a differentiable full 3-D modified total potential Phi_total(x,y,z).',
 'hydrus_total_potential_available_in_frozen_api':False,
 'B01_B24_total_potential_hessian_executed':False,
 'B01_B24_hessian_status':'NOT EVALUATED',
 'next_requirement':'Implement and independently validate a model-consistent 3-D total-potential solver, without modifying frozen physics; test convergence at three preregistered steps before any galaxy Hessian result.',
 'interpretation':'Synthetic Hessian estimator passes but does not validate GQUMOND, a galaxy potential, or any Hessian-Jeans coupling.'
}
out=Path('/mnt/data/UDCT_v7_13_Hessian_Preflight_Results.json')
out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:report[k] for k in ['frozen_sha256_verified','synthetic_estimator_selftest','synthetic_quadratic_max_component_errors','synthetic_quartic_max_component_errors','B01_B24_hessian_status']},indent=2))
print(out)

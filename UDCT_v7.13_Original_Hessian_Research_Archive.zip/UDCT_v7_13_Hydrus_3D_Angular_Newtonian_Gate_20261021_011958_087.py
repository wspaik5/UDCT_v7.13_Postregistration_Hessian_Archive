#!/usr/bin/env python3
"""Reproducible 3D directional NEWTONIAN input audit, NOT GQUMOND/Jeans."""
import json, hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
names=['UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json','UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json']
I,E=[json.loads((P/n).read_text()) for n in names]
G=6.67430e-11; pc=3.085677581491367e16; a0=1.2e-10
M=float(I['mass_kg']); b=float(I['b_pc'])*pc; rh=float(I['rh_pc'])*pc
T=np.array(E['grid_results'][-1]['hessian_s_minus2'],float)
g0=np.array(E['grid_results'][-1]['gradient_m_s2'],float)
assert np.allclose(T,T.T,rtol=0,atol=1e-43)
N=4096; k=np.arange(N); zz=1-2*(k+.5)/N; th=k*np.pi*(3-np.sqrt(5)); u=np.stack([np.sqrt(1-zz**2)*np.cos(th),np.sqrt(1-zz**2)*np.sin(th),zz],axis=1)
rows=[]
for factor in [0.5,1,2,3]:
 r=factor*rh; x=r*u
 gi=G*M*x/(r*r+b*b)**1.5
 tide=x@T.T
 gt=gi+tide+g0
 Hinner=G*M/(r*r+b*b)**1.5*np.eye(3)[None,:,:]-3*G*M/(r*r+b*b)**2.5*x[:,:,None]*x[:,None,:]
 Htot=Hinner+T
 norm=lambda a:np.linalg.norm(a,axis=-1)
 hnorm=np.linalg.norm(Htot,axis=(1,2)); ihnorm=np.linalg.norm(Hinner,axis=(1,2))
 vals=np.linalg.eigvalsh(Htot)
 row={'r_over_rh':factor,'angular_samples':N,'external_uniform_over_a0':float(norm(g0)/a0),
 'total_gradient_over_a0':{'min':float(norm(gt).min()/a0),'median':float(np.median(norm(gt))/a0),'max':float(norm(gt).max()/a0)},
 'internal_gradient_over_a0':float(norm(gi)[0]/a0),
 'tidal_over_internal_gradient':{'min':float((norm(tide)/norm(gi)).min()),'median':float(np.median(norm(tide)/norm(gi))),'max':float((norm(tide)/norm(gi)).max())},
 'combined_hessian_over_internal':{'min':float((hnorm/ihnorm).min()),'median':float(np.median(hnorm/ihnorm)),'max':float((hnorm/ihnorm).max())},
 'combined_hessian_eigenvalue_min_s_minus2':float(vals[:,0].min()),
 'combined_hessian_eigenvalue_max_s_minus2':float(vals[:,-1].max())}
 rows.append(row)
 print(factor,'total/a0',row['total_gradient_over_a0'],'H ratio',row['combined_hessian_over_internal'])
report={'classification':'EXPLORATORY 3D NEWTONIAN directional input audit; NOT modified-gravity solution or observational velocity fit',
 'source_sha256':{n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in names},
 'constants':{'G_SI':G,'pc_m':pc,'a0_m_s2':a0},'method':'4096 deterministic Fibonacci-sphere directions per radius; baryonic Plummer + affine MW gradient and Hessian',
 'rows':rows,'limitations':['External MW field is Taylor-approximated at dwarf center','Plummer baryons are modeled, not individually fitted stellar velocities','No A-Qs/A-Qd constitutive law executed','No 3D modified potential or Jeans sign result','Angular extrema are sampled, not proven global bounds']}
out=P/'UDCT_v7_13_Hydrus_3D_Angular_Newtonian_Gate.json';out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('saved',out)

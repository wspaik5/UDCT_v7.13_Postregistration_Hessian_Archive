#!/usr/bin/env python3
"""Exploratory 3D delta-potential: frozen v7.10 GQUMOND minus QUMOND.
Zero Dirichlet delta potential on finite cube: NOT physical boundary / not prereg test.
"""
import json, hashlib, importlib.util,sys
from pathlib import Path
import numpy as np
from scipy.fft import dstn,idstn
R=Path('/mnt/data');P=R/'UDCT_v7_10_Postregistration_run.py';D=R/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D)=='a64440e1350ae8bf10eb3188ec34829b6d586abf275de5cdc841a50ad3478284'
assert sha(P)=='a4d1a07ebcaa06348be3022d0f1f6ca463347e00194f7fde59f2bd9dbcd521b7'
spec=importlib.util.spec_from_file_location('udct_frozen_delta',P);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
obj=m.DWARFS['Hydrus I'];M=m.ML*obj.luminosity*m.MSUN;b=obj.re_pc*m.PC;rh=b/np.sqrt(2**(2/3)-1)
# Use default external grid, as previously tested against smoke
extgrid=m.Grid(radial=180,polar=16,azimuth=24,disk_radial=120,disk_azimuth=64,disk_height=12)
e,H,_=m.V706.galactic_field(obj,extgrid)
L=6*rh

def solve(rhs,h):
 n=rhs.shape[0];k=np.arange(1,n+1);ev=2*(np.cos(np.pi*k/(n+1))-1)/h**2
 return idstn(dstn(rhs,type=1,norm='ortho')/(ev[:,None,None]+ev[None,:,None]+ev[None,None,:]),type=1,norm='ortho')

def lap(u,h):
 p=np.pad(u,1);return (p[2:,1:-1,1:-1]+p[:-2,1:-1,1:-1]+p[1:-1,2:,1:-1]+p[1:-1,:-2,1:-1]+p[1:-1,1:-1,2:]+p[1:-1,1:-1,:-2]-6*u)/h**2

def run(n,law,ellpc):
 h=L/(n+1);q=(np.arange(-1,n+3)-(n+1)/2)*h
 x=np.meshgrid(q,q,q,indexing='ij');r2=sum(v*v for v in x);den=r2+b*b
 g=np.stack([m.G*M*x[i]/den**1.5+e[i]+sum(H[i,j]*x[j] for j in range(3)) for i in range(3)])
 Hess=np.empty((3,3)+r2.shape)
 for i in range(3):
  for j in range(3):
   Hess[i,j]=m.G*M*((1 if i==j else 0)/den**1.5-3*x[i]*x[j]/den**2.5)+H[i,j]
 g2=np.sum(g*g,axis=0);s=np.sum(Hess*Hess,axis=(0,1))
 nu,wh=m.gq_kernel(g2,s,ellpc*m.PC,law);nuq,_=m.gq_kernel(g2,s,None,law)
 flux=(nu-nuq)[None,...]*g;ten=wh[None,None,...]*Hess
 core=(slice(2,-2),)*3
 def shift(i,k):
  sl=[slice(2,-2)]*3;sl[i]=slice(2+k,-2+k if k!=2 else None);return tuple(sl)
 # explicit slices robust for n cube
 def sl(offset):return tuple(slice(2+d,2+d+n) for d in offset)
 rhs=np.zeros((n,n,n));grad=np.zeros_like(rhs);hess=np.zeros_like(rhs)
 for i in range(3):
  off=[0]*3;off[i]=1;sp=sl(off);off[i]=-1;sm=sl(off)
  grad+=(flux[i][sp]-flux[i][sm])/(2*h)
  hess+=(ten[i,i][sp]-2*ten[i,i][core]+ten[i,i][sm])/h**2
  for j in range(i+1,3):
   pp=[0]*3;pp[i]=1;pp[j]=1
   pm=[0]*3;pm[i]=1;pm[j]=-1
   mp=[0]*3;mp[i]=-1;mp[j]=1
   mm=[0]*3;mm[i]=-1;mm[j]=-1
   hess+=2*(ten[i,j][sl(pp)]-ten[i,j][sl(pm)]-ten[i,j][sl(mp)]+ten[i,j][sl(mm)])/(4*h*h)
 rhs=grad-0.5*hess
 pot=solve(rhs,h)
 residual=np.linalg.norm(lap(pot,h)-rhs)/max(np.linalg.norm(rhs),1e-300)
 mid=n//2
 # gradient of delta potential at central interior sample, expressed as acceleration / a0
 dphi=np.array([(pot[mid+1,mid,mid]-pot[mid-1,mid,mid]),(pot[mid,mid+1,mid]-pot[mid,mid-1,mid]),(pot[mid,mid,mid+1]-pot[mid,mid,mid-1])])/(2*h)
 return {'n':n,'spacing_over_rh':h/rh,'ell_pc':ellpc,'law':law.name,'rms_delta_source_s_minus2':float(np.sqrt(np.mean(rhs**2))),'rms_hessian_source_s_minus2':float(np.sqrt(np.mean((0.5*hess)**2))),'center_delta_phi_over_a0_rh':float(pot[mid,mid,mid]/(m.A0*rh)),'center_delta_acceleration_over_a0':float(np.linalg.norm(dphi)/m.A0),'rel_discrete_poisson_residual':float(residual),'finite':bool(np.isfinite(pot).all()),'boundary':'delta_phi=0 on finite cube faces'}

out={'status':'EXPLORATORY_FINITE_BOX_NOT_PHYSICAL_NOT_PREREG','description':'3D discrete solution of difference between frozen GQUMOND and matching QUMOND source, Newtonian Plummer plus fixed Galactic Taylor field','boundary':'zero Dirichlet difference potential at cube faces, box side 6 rh; not justified physical exterior solution','caveat':'mesh convergence alone does not remove finite-boundary bias; center acceleration is an exploratory diagnostic, not observable','source_v710_sha256':sha(P),'source_v706_sha256':sha(D),'rh_pc':float(rh/m.PC),'external_acceleration_over_a0':float(np.linalg.norm(e)/m.A0),'results':[]}
for lawname in ('A-Qs','A-Qd','A-f1/2'):
 law=next(x for x in m.PART_A_LAWS if x.name==lawname)
 for ell in (1.,3.,10.):
  for n in (20,28,36):
   result=run(n,law,ell);out['results'].append(result)
   print(lawname,ell,n,'dphi/a0rh',round(result['center_delta_phi_over_a0_rh'],8),'acc/a0',round(result['center_delta_acceleration_over_a0'],8),'res',result['rel_discrete_poisson_residual'],flush=True)
assert all(z['finite'] and z['rel_discrete_poisson_residual']<1e-8 for z in out['results'])
file=R/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.json';file.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print('SAVED',file)

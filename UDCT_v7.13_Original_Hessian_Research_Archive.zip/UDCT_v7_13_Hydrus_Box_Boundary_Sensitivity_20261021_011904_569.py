#!/usr/bin/env python3
"""Exploratory finite-box sensitivity; reuses frozen v7.10 source and prior 3D solver.
This is NOT a physical exterior boundary solution or registered B01-B24 validation.
"""
import importlib.util,sys,json,hashlib
from pathlib import Path
p=Path('/mnt/data/UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py')
src=p.read_text(); src=src[:src.index("out={'status'")]
# Import definitions without executing the previous campaign.
ns={'__file__':str(p)}
exec(compile(src,str(p),'exec'),ns)
m=ns['m'];rh=ns['rh'];R=Path('/mnt/data')
rows=[]
# Fixed spacing = rh/6, box side = 4,6,8 rh, odd n centers exactly at origin
for lawname in ('A-Qs','A-f1/2'):
 law=next(z for z in m.PART_A_LAWS if z.name==lawname)
 for ell in (1.,10.):
  for box in (4.,6.,8.):
   n=int(6*box)-1
   ns['L']=box*rh
   # run function resolves global namespace ns
   r=ns['run'](n,law,ell)
   r['box_side_over_rh']=box
   rows.append(r)
   print(lawname,ell,box,n,r['center_delta_phi_over_a0_rh'],r['center_delta_acceleration_over_a0'],flush=True)
output={'status':'EXPLORATORY_BOUNDARY_SENSITIVITY_NOT_PHYSICAL_NOT_PREREG','method':'fixed grid spacing rh/6, odd center grid, zero Dirichlet difference potential at cube faces','warning':'zero Dirichlet on finite faces is not the asymptotic GQUMOND-QUMOND boundary; box sensitivity is not physical convergence','source_v710_sha256':ns['sha'](ns['P']),'source_v706_sha256':ns['sha'](ns['D']),'solver_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'results':rows}
out=R/'UDCT_v7_13_Hydrus_Box_Boundary_Sensitivity.json';out.write_text(json.dumps(output,indent=2)+'\n');print('SAVED',out)

#!/usr/bin/env python3
"""Common Galactocentric frame Newtonian Hessian audit. Not a GQUMOND field solve.
At Plummer radius r_h, evaluate stellar Hessian for radial direction pointing
from Hydrus I towards Galactic center; also sample sphere for directional sensitivity.
The external Hessian is held spatially constant (tidal approximation).
"""
import json, numpy as np
from pathlib import Path
P=Path(__file__).resolve().parent
I=json.loads((P/'UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json').read_text())
E=json.loads((P/'UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json').read_text())
G=6.67430e-11; pc=3.085677581491367e16
M=I['mass_kg']; b=I['b_pc']*pc; r=I['rh_pc']*pc
Hext=np.array(E['grid_results'][-1]['hessian_s_minus2'])
R=np.array(E['hydrus_galactocentric_kpc'],float)
n=-R/np.linalg.norm(R)
# Hessian Phi=-GM/sqrt(r²+b²): GM/(r²+b²)^3/2 I - 3 GM r²/(r²+b²)^5/2 n n^T
A=G*M/(r*r+b*b)**1.5
B=3*G*M*r*r/(r*r+b*b)**2.5
def h_in(n):return A*np.eye(3)-B*np.outer(n,n)
def metrics(n):
 h=h_in(n); tot=h+Hext
 return {'internal_norm_s_minus2':float(np.linalg.norm(h)), 'total_norm_s_minus2':float(np.linalg.norm(tot)), 'total_over_internal':float(np.linalg.norm(tot)/np.linalg.norm(h)), 'total_eigenvalues_s_minus2':np.linalg.eigvalsh(tot).tolist(), 'total_trace_s_minus2':float(np.trace(tot)), 'internal_hessian_s_minus2':h.tolist(), 'total_hessian_s_minus2':tot.tolist()}
rng=np.random.default_rng(71315)
D=rng.normal(size=(100000,3)); D/=np.linalg.norm(D,axis=1)[:,None]
# vectorized trace(Hin Hext) = A trace(Hext)-B n^T Hext n
nin=np.sqrt(3*A*A-2*A*B+B*B)
next=np.linalg.norm(Hext)
cross=A*np.trace(Hext)-B*np.einsum('ni,ij,nj->n',D,Hext,D)
ratios=np.sqrt(nin**2+next**2+2*cross)/nin
w,V=np.linalg.eigh(Hext)
# exact extrema over all radial directions: quadratic form Rayleigh quotient
cross_candidates=A*np.trace(Hext)-B*w
bounds=np.sqrt(nin**2+next**2+2*np.array([min(cross_candidates),max(cross_candidates)]))/nin
out={'classification':'EXPLORATORY common-frame Newtonian tensor sum; NOT 3D GQUMOND or Jeans fit',
'input_files':[I['model'],'UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json'],
'frame':'Galactocentric Cartesian frame from external control; internal spherical Plummer radial direction n=-R/|R|, toward Galactic center, at r=r_h',
'galactocentric_position_kpc':R.tolist(),'direction_toward_galactic_center':n.tolist(),
'point_toward_galactic_center':metrics(n),
'exact_directional_bounds_total_over_internal':bounds.tolist(),
'random_direction_sample_count':len(D), 'random_direction_seed':71315,
'random_direction_quantiles_total_over_internal':{str(q):float(np.quantile(ratios,q)) for q in [0,.05,.5,.95,1]},
'validation':{'external_trace_near_zero':bool(abs(np.trace(Hext))<1e-10*next), 'internal_eigenvalues_match_prior':bool(np.allclose(np.linalg.eigvalsh(h_in(n)),I['analytic_hessian_s_minus2'] and np.linalg.eigvalsh(np.array(I['analytic_hessian_s_minus2'])),rtol=1e-9,atol=0)), 'sample_within_exact_bounds':bool(np.min(ratios)>=bounds[0]-1e-12 and np.max(ratios)<=bounds[1]+1e-12)},
'limitations':['Hydrus baryonic Plummer control, not measured 3D star distribution','Direction toward Galactic center is one physically defined radial location, not a measurement location for a star','External Hessian treated constant across dwarf; neglects higher spatial derivatives','No modified gravity potential, no stellar velocity fitting, no B01-B24 recalculation']}
assert all(out['validation'].values()),out['validation']
(P/'UDCT_v7_13_Hydrus_Common_Frame_Newtonian_Audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'toward_GC_ratio':out['point_toward_galactic_center']['total_over_internal'],'exact_bounds':bounds.tolist(),'median':out['random_direction_quantiles_total_over_internal']['0.5'],'checks':out['validation']},indent=2))

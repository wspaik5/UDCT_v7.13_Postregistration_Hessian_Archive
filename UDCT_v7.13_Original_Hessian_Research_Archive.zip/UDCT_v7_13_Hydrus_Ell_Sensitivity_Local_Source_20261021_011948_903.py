#!/usr/bin/env python3
"""Exploratory local 3D source diagnostic using frozen v7.10 law; NOT full 3D solution."""
import json,hashlib,sys,importlib.util
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data')
P=ROOT/'UDCT_v7_10_Postregistration_run.py'
D=ROOT/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py'
assert hashlib.sha256(D.read_bytes()).hexdigest()=='a64440e1350ae8bf10eb3188ec34829b6d586abf275de5cdc841a50ad3478284'
spec=importlib.util.spec_from_file_location('frozen_udct_v710',P)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
assert hashlib.sha256(P.read_bytes()).hexdigest()=='a4d1a07ebcaa06348be3022d0f1f6ca463347e00194f7fde59f2bd9dbcd521b7'
obj=m.DWARFS['Hydrus I']; grid=m.Grid(radial=180,polar=16,azimuth=24,disk_radial=40,disk_azimuth=24,disk_height=8)
e,H,_=m.V706.galactic_field(obj,grid)
M=m.ML*obj.luminosity*m.MSUN;b=obj.re_pc*m.PC;rh=b/np.sqrt(2**(2/3)-1)
# Newtonian Plummer internal gradient and Hessian; Galactic Taylor field about dwarf center.
def field(x):
 r2=float(x@x);q=r2+b*b
 g=m.G*M*x/q**1.5+e+H@x
 h=m.G*M*(np.eye(3)/q**1.5-3*np.outer(x,x)/q**2.5)+H
 return g,h

def constit(x,law,ell):
 g,h=field(x)
 nu,wh=m.gq_kernel(np.array([g@g]),np.array([np.sum(h*h)]),ell,law)
 return float(nu[0])*g,float(wh[0])*h

def source(x,law,ell,step):
 # 3D central differences, including mixed derivatives of tensor P_ij
 d=step;eye=np.eye(3);flux0,p0=constit(x,law,ell)
 div=0.;dd=0.
 for i in range(3):
  fp,pp=constit(x+d*eye[i],law,ell);fm,pm=constit(x-d*eye[i],law,ell)
  div+=(fp[i]-fm[i])/(2*d)
  dd+=(pp[i,i]-2*p0[i,i]+pm[i,i])/d**2
  for j in range(i+1,3):
   pp1=constit(x+d*eye[i]+d*eye[j],law,ell)[1][i,j]
   pp2=constit(x+d*eye[i]-d*eye[j],law,ell)[1][i,j]
   pp3=constit(x-d*eye[i]+d*eye[j],law,ell)[1][i,j]
   pp4=constit(x-d*eye[i]-d*eye[j],law,ell)[1][i,j]
   dd+=2*(pp1-pp2-pp3+pp4)/(4*d*d)
 return {'gradient_source':div,'hessian_source':-0.5*dd,'total_source':div-0.5*dd}


# Exploratory extension: frozen law, independent ell scan, fixed coarse external field.
direction=-m.V706.galactocentric_position(obj);direction/=np.linalg.norm(direction)
ells=[0.03,0.1,0.3,1.0,3.0,10.0]
steps=[0.08,0.04,0.02]
rows=[]
for radius in [1.,2.,3.]:
 x=radius*rh*direction
 rho=3*M*b*b/(4*np.pi*(float(x@x)+b*b)**2.5)
 norm=4*np.pi*m.G*rho
 for law in [m.BASE_LAW]+list(m.PART_A_LAWS):
  q=source(x,law,None,0.02*rh)['total_source']/norm
  for ell in ells:
   vals=[source(x,law,ell*m.PC,step*rh) for step in steps]
   totals=[v['total_source']/norm for v in vals]
   hess=[v['hessian_source']/norm for v in vals]
   rows.append({'r_over_rh':radius,'law':law.name,'ell_pc':ell,'control':float(q), 'source_by_step':list(map(float,totals)), 'hessian_by_step':list(map(float,hess)), 'difference_at_fine_step':float(totals[-1]-q),'fractional_difference_at_fine_step':float((totals[-1]-q)/q), 'step_disagreement':float(abs(totals[-1]-totals[-2])),'signal_to_step_disagreement':float(abs(totals[-1]-q)/max(abs(totals[-1]-totals[-2]),1e-30))})
result={'classification':'EXPLORATORY_LOCAL_SOURCE_ELL_SCAN_NOT_GLOBAL_3D_SOLUTION','source_v710_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'source_v706_sha256':hashlib.sha256(D.read_bytes()).hexdigest(),'external_field_grid':'smoke','radii_rh':[1,2,3],'ell_pc':ells,'steps_rh':steps,'units':'source normalized by 4pi G stellar density','rows':rows,'cautions':['Local 3D differential source only; no boundary value problem solved','No Jeans or stellar velocity likelihood','Finite difference truncation and external grid errors not fully bounded','This is an exploratory extension, not a preregistered outcome']}
path=ROOT/'UDCT_v7_13_Hydrus_Ell_Sensitivity_Local_Source.json';path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
for law in ['BASE','A-f1/2','A-f2','A-Qs','A-Qd']:
 print(law,[(r['ell_pc'],round(r['fractional_difference_at_fine_step']*100,5),round(r['signal_to_step_disagreement'],2)) for r in rows if r['law']==law and r['r_over_rh']==2.0])
print('SAVED',path)

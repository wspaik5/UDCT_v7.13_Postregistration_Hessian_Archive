#!/usr/bin/env python3
"""Exploratory 3D Newtonian external-field input gate; NOT a GQUMOND solver."""
import json, hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
files=['UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json','UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json']
I,E=[json.loads((P/f).read_text()) for f in files]
G=6.67430e-11; pc=3.085677581491367e16; a0=1.2e-10
M=float(I['mass_kg']); b=float(I['b_pc'])*pc; rh=float(I['rh_pc'])*pc
T=np.array(E['grid_results'][-1]['hessian_s_minus2'],float)
g0=np.array(E['grid_results'][-1]['gradient_m_s2'],float)
R=np.array(E['hydrus_galactocentric_kpc'],float); n=-R/np.linalg.norm(R)
assert np.allclose(T,T.T,atol=1e-43,rtol=0)
assert abs(np.trace(T))<1e-10*np.linalg.norm(T)
# Affine Taylor approximation to the EXTERNAL gradient, around the dwarf center.
# The stellar Plummer gradient is evaluated analytically in the SAME frame.
rows=[]
for direction,label in [(n,'toward_MW_center'),(-n,'away_from_MW_center'),(np.array([0.,0.,0.]),'center')]:
 for scale in ([0.] if label=='center' else [0.5,1.,2.,3.]):
  x=scale*rh*direction; r=np.linalg.norm(x)
  gin=G*M*x/(r*r+b*b)**1.5
  gout=g0+T@x
  gtot=gin+gout
  tide=T@x
  rows.append({'direction':label,'r_over_rh':scale,'external_uniform_gradient_m_s2':float(np.linalg.norm(g0)),'internal_gradient_m_s2':float(np.linalg.norm(gin)),'external_tidal_gradient_m_s2':float(np.linalg.norm(tide)),'total_gradient_m_s2':float(np.linalg.norm(gtot)),'external_tide_over_uniform':float(np.linalg.norm(tide)/np.linalg.norm(g0)),'total_over_a0':float(np.linalg.norm(gtot)/a0),'external_field_over_a0':float(np.linalg.norm(gout)/a0),'external_gradient_dot_radial_m_s2':float(gout@direction) if r else None})
# Exact Newtonian acceleration for affine MW field + spherical Plummer is -grad(phi).
# External tidal Hessian trace is zero; Poisson source must equal stellar density.
checks=[]
for f in [0.,0.5,1.,2.,3.]:
 r=f*rh
 H=(G*M/(r*r+b*b)**1.5)*np.eye(3)-(3*G*M*r*r/(r*r+b*b)**2.5)*np.outer(n,n)
 rho=3*M*b*b/(4*np.pi*(r*r+b*b)**2.5)
 residual=(np.trace(H+T)-4*np.pi*G*rho)/(4*np.pi*G*rho)
 checks.append({'r_over_rh':f,'poisson_trace_relative_error':float(residual)})
out={'classification':'EXPLORATORY physically dimensioned common-frame Newtonian gradient+Hessian input; NOT 3D GQUMOND, Jeans or stellar-velocity fit',
'input_sha256':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in files},'constants':{'G_SI':G,'pc_m':pc,'reference_a0_m_s2':a0},
'model':'baryonic Plummer Hydrus I + constant Milky Way gradient and Hessian Taylor approximation',
'external_uniform_gradient_m_s2':g0.tolist(),'external_hessian_s_minus2':T.tolist(),'toward_MW_center_unit_vector':n.tolist(),
'rows':rows,'newtonian_poisson_trace_checks':checks,
'validation':{'external_hessian_symmetric':True,'external_trace_vacuum':True,'poisson_trace_max_relative_error':max(abs(c['poisson_trace_relative_error']) for c in checks)},
'limitations':['Inputs from previous exploratory modeled Newtonian controls; not direct measured 3D field','a0 is reference only; not a fitted value','External Milky Way gradient Taylor expansion only, not global 3D boundary conditions','No original frozen A-Qs/A-Qd law executed here','No self-consistent modified gravity 3D field solve','No stellar line-of-sight velocity likelihood or B01-B24 rerun']}
assert out['validation']['poisson_trace_max_relative_error']<1e-10
path=P/'UDCT_v7_13_Hydrus_External_Field_3D_Input_Gate.json';path.write_text(json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
for row in rows: print(row['direction'],row['r_over_rh'], 'external/a0',round(row['external_field_over_a0'],5),'tide/uniform',round(row['external_tide_over_uniform'],5),'total/a0',round(row['total_over_a0'],5))
print('Poisson max relative trace error:',out['validation']['poisson_trace_max_relative_error'])
print('Saved:',path)

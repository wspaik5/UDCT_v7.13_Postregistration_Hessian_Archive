#!/usr/bin/env python3
"""Exploratory Newtonian Hydrus I: distinguish external uniform acceleration from tidal Hessian.
Not a GQUMOND field solve, Jeans fit, or observational stellar velocity fit.
"""
import json, hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
files=['UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json','UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json']
I,E=[json.loads((P/f).read_text()) for f in files]
G=6.67430e-11; pc=3.085677581491367e16
M=float(I['mass_kg']); b=float(I['b_pc'])*pc; rh=float(I['rh_pc'])*pc
T=np.array(E['grid_results'][-1]['hessian_s_minus2'],float)
gext=np.array(E['grid_results'][-1]['gradient_m_s2'],float)
R=np.array(E['hydrus_galactocentric_kpc'],float); n=-R/np.linalg.norm(R)
assert np.allclose(T,T.T,rtol=0,atol=1e-43)
assert abs(np.trace(T))<1e-9*np.linalg.norm(T)
rows=[]
for f in [0.25,0.5,1,1.5,2,3,5]:
 r=f*rh
 # Internal Plummer acceleration magnitude, external uniform field, and differential tidal acceleration
 gint=G*M*r/(r*r+b*b)**1.5
 tidal=np.linalg.norm(T@(r*n))
 # local gradient of potential = internal + external uniform + tide; n points toward GC
 gradint=(gint*n)
 total=gradint+gext+T@(r*n)
 # relative sizes of Hessian and tidal acceleration are different from uniform external field
 A=G*M/(r*r+b*b)**1.5; B=3*G*M*r*r/(r*r+b*b)**2.5
 H=A*np.eye(3)-B*np.outer(n,n)
 rows.append({'r_over_rh':f,'internal_acceleration_m_s2':float(gint),'external_uniform_acceleration_m_s2':float(np.linalg.norm(gext)),'tidal_differential_acceleration_m_s2':float(tidal),'external_uniform_over_internal_acceleration':float(np.linalg.norm(gext)/gint),'tidal_over_internal_acceleration':float(tidal/gint),'external_over_internal_hessian_norm':float(np.linalg.norm(T)/np.linalg.norm(H)),'combined_gradient_norm_m_s2':float(np.linalg.norm(total))})
out={'classification':'EXPLORATORY Newtonian external-field versus tide audit; not GQUMOND or Jeans test','inputs_sha256':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in files},'external_gradient_convention':'gradient of Newtonian potential; gravitational acceleration is negative gradient','model':'Hydrus I spherical baryonic Plummer + uniform MW gradient + linear MW tidal term at Hydrus center','galactocentric_direction':'toward MW center','assumptions':['fixed Plummer mass and scale from previous exploratory control','Milky Way external gradient and Hessian spatially constant/linearized over dwarf','only one radial direction','external field input is a model estimate, not direct measured stellar acceleration'],'rows':rows,'interpretation':['Uniform external gradient has zero Hessian yet can influence MOND external-field effects','Hessian ratios must not be interpreted as acceleration ratios','No 3D A-Qs or A-Qd modified potential solved','No direct fit to Hydrus I individual stellar velocities','No B01-B24 verdict changed']}
path=P/'UDCT_v7_13_Hydrus_External_Field_vs_Tide_Audit.json'
path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
for row in rows:print(f"{row['r_over_rh']:4g} rh: ext uniform/internal={row['external_uniform_over_internal_acceleration']:.3f}, tidal/internal={row['tidal_over_internal_acceleration']:.5f}, Hessian ext/internal={row['external_over_internal_hessian_norm']:.3f}")
print('Saved',path)

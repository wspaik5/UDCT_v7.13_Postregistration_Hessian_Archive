#!/usr/bin/env python3
"""Posthoc exploratory: Galactic quadrature grid sensitivity of local 3D GQUMOND source.
Uses frozen v7.10/v7.06 laws, not the registered six-arm Jeans validation.
"""
import hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
P=ROOT/'UDCT_v7_10_Postregistration_run.py';D=ROOT/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py'
assert hashlib.sha256(P.read_bytes()).hexdigest()=='a4d1a07ebcaa06348be3022d0f1f6ca463347e00194f7fde59f2bd9dbcd521b7'
assert hashlib.sha256(D.read_bytes()).hexdigest()=='a64440e1350ae8bf10eb3188ec34829b6d586abf275de5cdc841a50ad3478284'
spec=importlib.util.spec_from_file_location('v710_grid_audit',P);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
obj=m.DWARFS['Hydrus I'];M=m.ML*obj.luminosity*m.MSUN;b=obj.re_pc*m.PC;rh=b/np.sqrt(2**(2/3)-1)
direction=-m.V706.galactocentric_position(obj);direction/=np.linalg.norm(direction)

def calc(e,H,x,law,ell,h):
    def c(y):
        r2=y@y;q=r2+b*b
        g=m.G*M*y/q**1.5+e+H@y
        t=m.G*M*(np.eye(3)/q**1.5-3*np.outer(y,y)/q**2.5)+H
        nu,w=m.gq_kernel(np.array([g@g]),np.array([np.sum(t*t)]),ell,law)
        return float(nu[0])*g,float(w[0])*t
    eye=np.eye(3);f0,p0=c(x);div=0.;dd=0.
    for i in range(3):
        fp,pp=c(x+h*eye[i]);fm,pm=c(x-h*eye[i]);div+=(fp[i]-fm[i])/(2*h)
        dd+=(pp[i,i]-2*p0[i,i]+pm[i,i])/h**2
        for j in range(i+1,3):
            a=c(x+h*eye[i]+h*eye[j])[1][i,j]
            b1=c(x+h*eye[i]-h*eye[j])[1][i,j]
            c1=c(x-h*eye[i]+h*eye[j])[1][i,j]
            d=c(x-h*eye[i]-h*eye[j])[1][i,j]
            dd+=2*(a-b1-c1+d)/(4*h*h)
    return div-0.5*dd

grids={'smoke':m.Grid(radial=180,polar=16,azimuth=24,disk_radial=40,disk_azimuth=24,disk_height=8),
       'default':m.Grid(radial=360,polar=24,azimuth=36,disk_radial=120,disk_azimuth=64,disk_height=12)}
results={}
for name,grid in grids.items():
    e,H,_=m.V706.galactic_field(obj,grid)
    rows=[]
    for rr in (1.,2.,3.):
        x=rr*rh*direction;rho=3*M*b*b/(4*np.pi*(x@x+b*b)**2.5);norm=4*np.pi*m.G*rho
        for law in (m.BASE_LAW,m.PART_A_LAWS[0],m.PART_A_LAWS[2],m.PART_A_LAWS[3]):
            q=calc(e,H,x,law,None,.02*rh)/norm
            for ell in (1.,3.,10.):
                s=calc(e,H,x,law,ell*m.PC,.02*rh)/norm
                rows.append(dict(r_rh=rr,law=law.name,ell_pc=ell,qumond=q,gqumond=s,relative_increment=(s-q)/q))
    results[name]={'e':e.tolist(),'H':H.tolist(),'rows':rows}
    print(name,'|e|=',np.linalg.norm(e),'|H|=',np.linalg.norm(H),flush=True)
comparisons=[]
for a,b1 in zip(results['smoke']['rows'],results['default']['rows']):
    assert (a['r_rh'],a['law'],a['ell_pc'])==(b1['r_rh'],b1['law'],b1['ell_pc'])
    comparisons.append(dict(r_rh=a['r_rh'],law=a['law'],ell_pc=a['ell_pc'],smoke_increment=a['relative_increment'],default_increment=b1['relative_increment'],absolute_increment_shift=b1['relative_increment']-a['relative_increment'],relative_increment_shift=abs(b1['relative_increment']-a['relative_increment'])/max(abs(b1['relative_increment']),1e-30)))
result={'status':'POSTHOC_EXPLORATORY_GALACTIC_QUADRATURE_TWO_GRID_AUDIT','warning':'Not registered v7.13 six-arm Jeans test; not global 3D Poisson solution; no observed stellar fit','frozen_sha256':{'v710':hashlib.sha256(P.read_bytes()).hexdigest(),'v706':hashlib.sha256(D.read_bytes()).hexdigest()},'galactic_fields':results,'comparisons':comparisons,'max_absolute_increment_shift':max(abs(z['absolute_increment_shift']) for z in comparisons)}
out=ROOT/'UDCT_v7_13_Hydrus_External_Grid_Source_Audit.json';out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
for z in comparisons:
    if z['r_rh']==2 and z['ell_pc'] in (1.,10.):print(z)
print('saved',out)

#!/usr/bin/env python3
"""Post-hoc exploratory convergence audit of archived v7.13 local Hessian source increments.
No rerun of frozen laws, no 3D Poisson solution, no preregistered inference.
"""
import json,hashlib,math,statistics
from pathlib import Path
src=Path(__file__).with_name('UDCT_v7_13_Hydrus_Ell_Sensitivity_Local_Source.json')
dat=json.loads(src.read_text()); output=[]
for x in dat['rows']:
    a,b,c=map(float,x['hessian_by_step']) # h = .08,.04,.02 rh
    d1=b-a;d2=c-b
    order=math.log(abs(d1/d2),2) if d1*d2>0 and abs(d2)>0 else None
    extrap=c+(c-b)/3 # formal O(h^2) Richardson
    estimated=abs(extrap-c)
    relative=estimated/max(abs(extrap),1e-300)
    output.append(dict(radius_rh=x['r_over_rh'],law=x['law'],ell_pc=x['ell_pc'],hessian_increments=[a,b,c],observed_order=order,richardson_increment=extrap,estimated_relative_discretization=relative,control=x['control'],richardson_relative_to_control=extrap/x['control'],monotone_difference=(d1*d2>0)))
summary={}
for law in sorted(set(x['law'] for x in output)):
    q=[x for x in output if x['law']==law]
    summary[law]=dict(n=len(q),median_relative_error=statistics.median(x['estimated_relative_discretization'] for x in q),max_relative_error=max(x['estimated_relative_discretization'] for x in q),monotone_count=sum(x['monotone_difference'] for x in q),orders=[round(x['observed_order'],3) for x in q if x['observed_order'] is not None])
selected=[x for x in output if x['radius_rh']==2 and x['ell_pc'] in (1,3,10)]
result=dict(classification='POSTHOC_EXPLORATORY_NUMERICAL_AUDIT_NOT_CONFIRMATORY',input_file=src.name,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),method='Second-order Richardson extrapolation of isolated Hessian source increment at h/rh = 0.08,0.04,0.02; assumes asymptotic h^2 behavior; no uncertainty from Galactic-field quadrature, model choices, boundary conditions',summary=summary,selected_at_2rh=selected,all_rows=output,caveats=['This analyzes prior archived output; it does not independently recompute the gravitational source.','No global 3D potential or Jeans solution; no stellar-velocity observational fit.','A small estimated stencil error does not bound Galactic-field quadrature, truncation, or model uncertainty.'])
out=src.with_name('UDCT_v7_13_Hydrus_Hessian_Increment_Convergence_Audit.json');out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'summary':summary,'selected':selected},indent=2))

#!/usr/bin/env python3
"""Orientation-independent bounds and illustrative rotations of two existing Newtonian Hessian controls.
This is NOT physical alignment, modified gravity, Jeans fitting, or new observation.
"""
import json
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent
internal=json.loads((root/'UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json').read_text())
external=json.loads((root/'UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json').read_text())
A=np.array(internal['analytic_hessian_s_minus2'],float)
B=np.array(external['grid_results'][-1]['hessian_s_minus2'],float)
scale=1e32
a=A*scale;b=B*scale
na=np.linalg.norm(a);nb=np.linalg.norm(b)
wa=np.linalg.eigvalsh(a);wb=np.linalg.eigvalsh(b)
# Trace(A RBRt) optimized by rearrangement inequality; trace of product, not sum
# Norm squared of A+RBRt = norm(A)^2 + norm(B)^2 + 2 Tr(A RBRt)
inner_min=float(np.dot(wa,wb[::-1]));inner_max=float(np.dot(wa,wb))
min_norm=float(np.sqrt(max(0,na**2+nb**2+2*inner_min)))
max_norm=float(np.sqrt(max(0,na**2+nb**2+2*inner_max)))
# Illustrative random SO(3) rotations only, fixed seed, not inferred actual orientation
rng=np.random.default_rng(713)
values=[]
for i in range(5000):
 q,_=np.linalg.qr(rng.normal(size=(3,3)))
 if np.linalg.det(q)<0:q[:,0]*=-1
 values.append(float(np.linalg.norm(a+q@b@q.T)))
res={
 'classification':'EXPLORATORY orientation-independent Newtonian tensor bounds; NOT a physically aligned Hydrus I field, NOT GQUMOND, NOT a Jeans test',
 'inputs':['UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json','UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json'],
 'units':'all Hessian norms in s^-2; values in fields ending _times_1e32 scaled by 1e32',
 'internal_norm_s_minus2':float(na/scale), 'external_norm_s_minus2':float(nb/scale),
 'external_to_internal_norm_ratio':float(nb/na),
 'total_norm_exact_orientation_min_s_minus2':min_norm/scale,
 'total_norm_exact_orientation_max_s_minus2':max_norm/scale,
 'total_to_internal_min_ratio':min_norm/na,'total_to_internal_max_ratio':max_norm/na,
 'total_trace_s_minus2':float((np.trace(a)+np.trace(b))/scale),
 'random_rotation_count':len(values),'random_rotation_seed':713,
 'random_rotation_norm_min_s_minus2':min(values)/scale,
 'random_rotation_norm_median_s_minus2':float(np.median(values)/scale),
 'random_rotation_norm_max_s_minus2':max(values)/scale,
 'warnings':['No physical common coordinate alignment established','Only compares Newtonian control tensors at one model evaluation point','A relative norm change is not a predicted MOND enhancement','No modified potential or B01-B24 Jeans results computed']
}
assert min_norm-1e-10 <= min(values) <= max(values) <= max_norm+1e-10
assert abs(np.trace(b))<1e-10*nb
out=root/'UDCT_v7_13_Hydrus_Hessian_Orientation_Bounds.json'
out.write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(res,indent=2))

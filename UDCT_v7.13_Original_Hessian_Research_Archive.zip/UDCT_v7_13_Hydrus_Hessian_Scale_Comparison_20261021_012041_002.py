#!/usr/bin/env python3
"""Reproduce a comparison of two PREVIOUSLY computed Newtonian Hessian controls.
No 3D modified gravity solution, no new observations, no coordinate-frame alignment.
"""
import json, math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
internal=json.loads((ROOT/'UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json').read_text())
external=json.loads((ROOT/'UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json').read_text())
H_in=np.asarray(internal['analytic_hessian_s_minus2'],dtype=float)
H_ext=np.asarray(external['grid_results'][-1]['hessian_s_minus2'],dtype=float)
G=6.67430e-11; PC=3.085677581491367e16; MSUN=1.98847e30
norm=lambda h:float(np.linalg.norm(h,'fro'))
scale=PC**3/(4*math.pi*G*MSUN)
result={
 'classification':'EXPLORATORY comparison of existing Newtonian controls; NOT a new modified-gravity or observed Hydrus I result',
 'input_files':[ 'UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json', 'UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json'],
 'internal_evaluation':'off-axis at r=r_h; baryonic Plummer analytic Hessian',
 'external_evaluation':'Milky Way external Newtonian Hessian at modeled Hydrus I location',
 'coordinate_warning':'Tensor components are NOT established in a common coordinate frame. Do not add these matrices or interpret componentwise differences.',
 'internal_frobenius_s_minus2':norm(H_in),
 'external_frobenius_s_minus2':norm(H_ext),
 'external_to_internal_frobenius_ratio':norm(H_ext)/norm(H_in),
 'internal_eigenvalues_s_minus2':np.linalg.eigvalsh(H_in).tolist(),
 'external_eigenvalues_s_minus2':np.linalg.eigvalsh(H_ext).tolist(),
 'internal_trace_s_minus2':float(np.trace(H_in)),
 'external_trace_s_minus2':float(np.trace(H_ext)),
 'internal_equivalent_density_Msun_pc3':float(np.trace(H_in)*scale),
 'external_equivalent_density_Msun_pc3':float(np.trace(H_ext)*scale),
 'invariant_total_hessian_frobenius_bounds_s_minus2': [abs(norm(H_in)-norm(H_ext)),norm(H_in)+norm(H_ext)],
 'not_done':['No physically aligned internal/external tensor sum','No full 3D GQUMOND field solution','No Jeans B01-B24 cross-test','No fit to stellar velocities']
}
assert np.allclose(H_in,H_in.T) and np.allclose(H_ext,H_ext.T)
assert abs(result['external_trace_s_minus2'])<1e-10*norm(H_ext)
assert result['internal_trace_s_minus2']>0
out=ROOT/'UDCT_v7_13_Hydrus_Hessian_Scale_Comparison.json'
out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
for k in ('internal_frobenius_s_minus2','external_frobenius_s_minus2','external_to_internal_frobenius_ratio','internal_equivalent_density_Msun_pc3','external_equivalent_density_Msun_pc3'):
 print(k,result[k])
print('saved',out)

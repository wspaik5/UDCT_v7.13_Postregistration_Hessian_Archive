#!/usr/bin/env python3
"""Exploratory local 3D source diagnostic using frozen v7.10 law; NOT full 3D solution."""
import json,hashlib,sys,importlib.util
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data')
P=ROOT/'UDCT_v7_10_Postregistration_run.py'
D=ROOT/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py'
assert hashlib.sha256(D.read_bytes()).hexdigest()=='a64440e1350ae8bf10eb3188ec34829b6d586abf275de5cdc841a50ad3478284'
spec=importlib.util.spec_from_file_location('frozen_udct_v710',P)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
assert hashlib.sha256(P.read_bytes()).hexdigest()=='a4d1a07ebcaa06348be3022d0f1f6ca463347e00194f7fde59f2bd9dbcd521b7'
obj=m.DWARFS['Hydrus I']; grid=m.Grid(radial=180,polar=16,azimuth=24,disk_radial=40,disk_azimuth=24,disk_height=8)
e,H,_=m.V706.galactic_field(obj,grid)
M=m.ML*obj.luminosity*m.MSUN;b=obj.re_pc*m.PC;rh=b/np.sqrt(2**(2/3)-1)
# Newtonian Plummer internal gradient and Hessian; Galactic Taylor field about dwarf center.
def field(x):
 r2=float(x@x);q=r2+b*b
 g=m.G*M*x/q**1.5+e+H@x
 h=m.G*M*(np.eye(3)/q**1.5-3*np.outer(x,x)/q**2.5)+H
 return g,h

def constit(x,law,ell):
 g,h=field(x)
 nu,wh=m.gq_kernel(np.array([g@g]),np.array([np.sum(h*h)]),ell,law)
 return float(nu[0])*g,float(wh[0])*h

def source(x,law,ell,step):
 # 3D central differences, including mixed derivatives of tensor P_ij
 d=step;eye=np.eye(3);flux0,p0=constit(x,law,ell)
 div=0.;dd=0.
 for i in range(3):
  fp,pp=constit(x+d*eye[i],law,ell);fm,pm=constit(x-d*eye[i],law,ell)
  div+=(fp[i]-fm[i])/(2*d)
  dd+=(pp[i,i]-2*p0[i,i]+pm[i,i])/d**2
  for j in range(i+1,3):
   pp1=constit(x+d*eye[i]+d*eye[j],law,ell)[1][i,j]
   pp2=constit(x+d*eye[i]-d*eye[j],law,ell)[1][i,j]
   pp3=constit(x-d*eye[i]+d*eye[j],law,ell)[1][i,j]
   pp4=constit(x-d*eye[i]-d*eye[j],law,ell)[1][i,j]
   dd+=2*(pp1-pp2-pp3+pp4)/(4*d*d)
 return {'gradient_source':div,'hessian_source':-0.5*dd,'total_source':div-0.5*dd}

out={'classification':'EXPLORATORY_LOCAL_3D_SOURCE_NOT_POTENTIAL_NOT_JEANS', 'source_v710_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'source_v706_sha256':hashlib.sha256(D.read_bytes()).hexdigest(), 'galaxy':'Hydrus I','model':'stellar Plummer + Galactic local Taylor; visible mass only','external_grid':'smoke (coarse) for speed; not high-precision external-field validation','rh_pc':rh/m.PC,'external_g_over_a0':float(np.linalg.norm(e)/m.A0),'ell_pc':1.0,'position':'toward Galactic center axis approximated by -galactocentric_position normalized', 'results':[],'limitations':['local source only; no global Poisson solution or physical boundary conditions','no 3D Jeans solve, no observed stellar-velocity likelihood','Galactic Taylor approximation and smoke-grid field','finite-difference step convergence not a proof of constitutive physical validity']}
direction=-m.V706.galactocentric_position(obj);direction=direction/np.linalg.norm(direction)
for r in [1.,2.,3.]:
 x=r*rh*direction
 row={'r_over_rh':r,'laws':{}}
 for law in [m.BASE_LAW]+list(m.PART_A_LAWS[-2:]):
  lawres={}
  for ell in [None,1.0*m.PC]:
   key='QUMOND_control' if ell is None else 'GQUMOND_ell1pc'
   vals=[source(x,law,ell,h*rh) for h in [0.08,0.04,0.02]]
   # Normalize source to Newtonian local 4piG rho
   rho=3*M*b*b/(4*np.pi*(float(x@x)+b*b)**2.5)
   norm=4*np.pi*m.G*rho
   lawres[key]={'source_over_4piG_rho':[float(v['total_source']/norm) for v in vals], 'gradient_over_4piG_rho':[float(v['gradient_source']/norm) for v in vals], 'hessian_over_4piG_rho':[float(v['hessian_source']/norm) for v in vals], 'relative_last_step_change':float(abs(vals[2]['total_source']-vals[1]['total_source'])/max(abs(vals[2]['total_source']),1e-100))}
  row['laws'][law.name]=lawres
 out['results'].append(row)
print('external g/a0',out['external_g_over_a0'])
for row in out['results']:
 print('r/rh',row['r_over_rh'])
 for name,d in row['laws'].items():
  a=d['QUMOND_control']['source_over_4piG_rho'][-1];b1=d['GQUMOND_ell1pc']['source_over_4piG_rho'][-1]
  print(name,'Q=',round(a,6),'GQ=',round(b1,6),'diff=',round(b1-a,6),'convergence',d['GQUMOND_ell1pc']['relative_last_step_change'])
outfile=ROOT/'UDCT_v7_13_Hydrus_Local_3D_Source_Gate.json';outfile.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print('SAVED',outfile)

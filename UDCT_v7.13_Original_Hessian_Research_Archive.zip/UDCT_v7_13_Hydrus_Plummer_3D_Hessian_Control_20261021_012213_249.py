#!/usr/bin/env python3
"""Exploratory analytic 3D baryonic Plummer control for Hydrus I.
NOT a full modified gravity solution, NOT any B01-B24 Hessian result.
"""
import hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
root=Path('/mnt/data/v713_hessian_stage')
plan=json.loads(Path('/mnt/data/UDCT_v7_13_Preregistration_Updated/preregistration_plan.json').read_text())
verified={}
for name,digest in plan['frozen_hashes'].items():
    path=root/name
    if not path.exists(): path=Path('/mnt/data/v713_b07_run')/name
    verified[name]=path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==digest
assert all(verified.values())
spec=importlib.util.spec_from_file_location('v706_plummer_control',root/'UDCT_v7_06_Hessian_Term_Sign_Audit_reproduce.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
obj=m.DWARFS['Hydrus I']; mass=m.ML*obj.luminosity*m.MSUN; b=obj.re_pc*m.PC
rh=b/np.sqrt(2**(2/3)-1)
# Explicit analytic 3-D Newtonian Plummer potential and its exact Hessian.
def phi(x): return -m.G*mass/np.sqrt(np.dot(x,x)+b*b)
def exact_hessian(x):
    d=np.dot(x,x)+b*b
    return m.G*mass*(np.eye(3)/d**1.5-3*np.outer(x,x)/d**2.5)
def numerical_hessian(x,h):
    e=np.eye(3)*h; hess=np.empty((3,3)); p0=phi(x)
    for i in range(3):
        hess[i,i]=(phi(x+e[i])-2*p0+phi(x-e[i]))/h**2
        for j in range(i):
            hess[i,j]=hess[j,i]=(phi(x+e[i]+e[j])-phi(x+e[i]-e[j])-phi(x-e[i]+e[j])+phi(x-e[i]-e[j]))/(4*h*h)
    return hess
# Off-axis sample tests all diagonal and mixed derivatives, r = r_h.
x=rh*np.array([0.3,0.4,np.sqrt(0.75)])
steps=plan['complete_protocol']['hessian_steps_rh']; assert steps==[.02,.01,.005]
truth=exact_hessian(x)
records=[]; mats=[]
for s in steps:
    H=numerical_hessian(x,s*rh); mats.append(H)
    records.append({'step_rh':s,'max_absolute_error_s_minus2':float(np.max(abs(H-truth))),
                    'relative_frobenius_error':float(np.linalg.norm(H-truth)/np.linalg.norm(truth)),
                    'max_component_s_minus2':float(np.max(abs(H))),
                    'eigenvalues_s_minus2':np.linalg.eigvalsh(H).tolist(),
                    'trace_s_minus2':float(np.trace(H)),
                    'frobenius_s_minus2':float(np.linalg.norm(H))})
D1=float(np.max(abs(mats[0]-mats[1])));D2=float(np.max(abs(mats[1]-mats[2])))
floor=1e-10*m.G*mass/rh**3
limit=max(floor,.05*float(np.max(abs(mats[2]))))
converged=bool(np.isfinite(mats).all() and D2<=limit and (D1>=D2 or (D1<=floor and D2<=floor)))
assert converged
assert records[2]['relative_frobenius_error']<records[1]['relative_frobenius_error']<records[0]['relative_frobenius_error']
report={'classification':'EXPLORATORY PHYSICAL 3D NEWTONIAN PLUMMER CONTROL ONLY',
 'source_sha256_all_verified':all(verified.values()),'model':'Hydrus I baryonic Plummer Newtonian analytic potential',
 'potential':'Phi=-GM/sqrt(r^2+b^2)','mass_kg':mass,'b_pc':obj.re_pc,'rh_pc':rh/m.PC,
 'evaluation_position_rh':(x/rh).tolist(),'analytic_hessian_s_minus2':truth.tolist(),
 'steps':records,'coarse_mid_difference_s_minus2':D1,'mid_fine_difference_s_minus2':D2,
 'preregistered_tolerance_s_minus2':limit,'three_step_hessian_convergence_control_pass':converged,
 'full_3d_modified_gravity_total_potential_available':False,'B01_B24_modified_hessian_executed':False,
 'limitations':'A self-gravitating Newtonian Plummer analytic control, not the frozen angle-averaged BASE/A-f2/A-Qs/A-Qd modified field solve; no GQUMOND field equation solved. No direct stellar velocity fit.',
 'next_gate':'Need a model-consistent differentiable 3D Phi_total solver and independent validation before computing Hessian on B01-B24.'}
out=Path('/mnt/data/UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json');out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'pass':converged,'relative_errors':[r['relative_frobenius_error'] for r in records], 'D_coarse_mid':D1,'D_mid_fine':D2,'tolerance':limit,'rh_pc':rh/m.PC},indent=2));print(out)

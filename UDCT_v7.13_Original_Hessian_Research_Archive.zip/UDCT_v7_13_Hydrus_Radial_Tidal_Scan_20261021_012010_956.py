#!/usr/bin/env python3
"""Exploratory Newtonian radial tidal scan; not a modified-gravity solve."""
import json
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
I=json.loads((P/'UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json').read_text())
E=json.loads((P/'UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json').read_text())
G=6.67430e-11; pc=3.085677581491367e16
M=I['mass_kg']; b=I['b_pc']*pc; rh=I['rh_pc']*pc
T=np.array(E['grid_results'][-1]['hessian_s_minus2'],float)
R=np.array(E['hydrus_galactocentric_kpc'],float); n=-R/np.linalg.norm(R)
rows=[]
for f in [0,0.25,0.5,1,1.5,2,3,5,10]:
 r=f*rh; A=G*M/(r*r+b*b)**1.5; B=3*G*M*r*r/(r*r+b*b)**2.5
 H=A*np.eye(3)-B*np.outer(n,n); S=H+T
 rows.append({'r_over_rh':f,'internal_norm_s_minus2':float(np.linalg.norm(H)), 'external_norm_s_minus2':float(np.linalg.norm(T)), 'external_over_internal':float(np.linalg.norm(T)/np.linalg.norm(H)), 'combined_over_internal':float(np.linalg.norm(S)/np.linalg.norm(H)), 'internal_eigenvalues_s_minus2':np.linalg.eigvalsh(H).tolist(), 'combined_eigenvalues_s_minus2':np.linalg.eigvalsh(S).tolist(),'trace_internal_s_minus2':float(np.trace(H)),'trace_combined_s_minus2':float(np.trace(S))})
output={'classification':'EXPLORATORY Newtonian Plummer + constant Milky Way tidal Hessian radial scan; not GQUMOND, not observed stellar kinematics', 'inputs':['UDCT_v7_13_Hydrus_Plummer_3D_Hessian_Control.json','UDCT_v7_13_Hydrus_External_Newtonian_Hessian_Exploratory.json'], 'direction':'toward Galactic center from Hydrus I', 'assumptions':['spherical baryonic Plummer','external Hessian constant over dwarf','one radial direction, not angle average','fixed mass and radius from prior model'], 'rows':rows,'no_claims':['No full 3D modified potential','No B01-B24 Jeans validation','No observational velocity fit']}
assert all(np.isfinite(v) for row in rows for k,v in row.items() if isinstance(v,float))
assert max(abs(x['trace_combined_s_minus2']-x['trace_internal_s_minus2']) for x in rows)<1e-42
out=P/'UDCT_v7_13_Hydrus_Radial_Tidal_Scan.json';out.write_text(json.dumps(output,indent=2)+'\n')
for r in rows:print(f"r/rh={r['r_over_rh']:>5}: ext/int={r['external_over_internal']:.4f}, total/int={r['combined_over_internal']:.4f}")
print('saved',out)

#!/usr/bin/env python3
"""Independent read-only audit of archived v7.13 six-arm endpoint profiles.
No galaxy field solve; no new physical results; not a confirmatory solver validation.
"""
import json,hashlib
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent
src=R/'UDCT_v7_13_B01_B24_All_Common_Profiles.npz'
inv=json.loads((R/'UDCT_v7_13_B01_B24_Trace_Inventory.json').read_text())
assert hashlib.sha256(src.read_bytes()).hexdigest()==inv['full_profiles_sha256']
arm_names=['default|0.002','refined|0.002','default|0.0005','refined|0.0005','validation|0.002','validation|0.0005']
raw=[json.loads((R/'UDCT_v7_13_B01_Full_Profile_Trace.json').read_text())]
for a,b in [(2,3),(4,4),(5,6),(7,9),(10,10),(11,12),(13,15),(16,17),(18,18),(19,20),(21,22),(23,24)]:
 d=json.loads((R/f'UDCT_v7_13_B{a:02d}_B{b:02d}_Full_Profile_Trace.json').read_text())
 raw.extend(d['targets'])
rows=[];exceptions=[]
with np.load(src) as archive:
 for i,rec in enumerate(raw,1):
  target=f'B{i:02d}';assert rec['target']==target
  endpoint_results=[]
  for p in rec['endpoints']:
   vals=[];native=[]
   for arm in arm_names:
    key=f'{target}|{p:g}|{arm}'
    v=np.asarray(archive[key],dtype=float)
    assert v.shape==(1200,) and np.isfinite(v).all()
    vals.append(v)
    matches=[r for r in rec['per_arm_logs'] if r['arm']==arm and abs(r['coordinate']-p)<1e-9]
    assert len(matches)==1
    native.append(float(matches[0]['native_min']))
   vals=np.stack(vals)
   # Independent explicit pairwise max disagreement to the two validation arms.
   E=float(np.max(np.abs(vals[:,:,None]-vals[4:6].T[None,:,:])))
   tau=max(1e-8,5*E)
   F=min(float(vals.min()),min(native))
   common_negative=bool(np.any(np.max(vals,axis=0)<-tau))
   sign=1 if F>tau else (-1 if common_negative else 0)
   status={1:'robust_positive',-1:'robust_negative',0:'unresolved_numerical_margin'}[sign]
   recorded=rec['results'][str(p)]
   for k,v in [('F',F),('E',E),('tau',tau)]:
    assert abs(v-recorded[k])<1e-10,(target,p,k,v,recorded[k])
   assert status==recorded['status'] and common_negative==recorded['common_negative']
   gap=float(np.min(vals)-min(native))
   endpoint_results.append({'coordinate':p,'status':status,'F':F,'E':E,'tau':tau,'min_common':float(vals.min()),'min_native':min(native),'native_common_min_gap':gap,'common_negative':common_negative})
   if gap>1e-4: exceptions.append({'target':target,'coordinate':p,'native_common_min_gap':gap})
  assert rec['bracket_status']=='unresolved_numerical_margin'
  rows.append({'target':target,'bracket_status':rec['bracket_status'],'endpoints':endpoint_results})
out={'status':'INDEPENDENT_POSTPROCESSING_RECALCULATION_ONLY','source_archive_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'targets':len(rows),'endpoints':sum(len(x['endpoints']) for x in rows),'profile_count':len(archive.files),'all_recorded_F_E_tau_status_reproduced':True,'brackets_unresolved':sum(x['bracket_status']=='unresolved_numerical_margin' for x in rows),'native_vs_common_min_gap_count_gt_1e-4':len(exceptions),'native_vs_common_min_gap_examples':exceptions[:12],'results':rows,'limits':['This audit independently recomputes decision arithmetic only; it does not independently verify the galaxy solver or preregistration chronology','Native grid minima can lie outside common sampled radial domain; the common-grid profile cannot certify their location','No midpoint history reconstruction, 3D total-potential Hessian, or observational fit']}
path=R/'UDCT_v7_13_Independent_Endpoint_Decision_Audit.json';path.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('results','native_vs_common_min_gap_examples')},indent=2))

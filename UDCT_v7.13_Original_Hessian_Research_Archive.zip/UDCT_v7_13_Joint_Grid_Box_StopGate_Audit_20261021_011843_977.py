#!/usr/bin/env python3
"""Independent post-processing of EXISTING exploratory Hydrus I delta-acceleration runs.
Not a preregistered six-arm Jeans or physical boundary validation.
"""
from pathlib import Path
import hashlib,json,numpy as np
root=Path(__file__).resolve().parent
files=['UDCT_v7_13_Radial_Acceleration_Convergence.json','UDCT_v7_13_Radial_Box_Size_Audit.json']
raw=[(root/f).read_bytes() for f in files]
res,box=[json.loads(x) for x in raw]
assert res['status'].startswith('EXPLORATORY') and box['status'].startswith('EXPLORATORY')
rows=[]
for law in ['A-Qs','A-f1/2']:
 rr=sorted((r for r in res['results'] if r['law']==law),key=lambda x:x['n'])
 bb=sorted((r for r in box['results'] if r['law']==law),key=lambda x:x['box_side_over_rh'])
 assert [r['n'] for r in rr]==[35,47,59]
 assert [r['box_side_over_rh'] for r in bb]==[6,8]
 for k,rad in enumerate([0.5,1.,2.]):
  vv=[np.array(r['radial_samples'][k]['delta_acceleration_vector_over_a0']) for r in rr]
  ww=[np.array(r['samples'][k]['interpolated_delta_gradient_vector_over_a0']) for r in bb]
  assert all(abs(r['radial_samples'][k]['actual_radius_rh']-rad)<1e-12 for r in rr)
  assert np.allclose(vv[1],ww[0],rtol=1e-8,atol=1e-12), (law,rad,'source mismatch')
  fine=float(100*np.linalg.norm(vv[2]-vv[1])/np.linalg.norm(vv[2]))
  coarse=float(100*np.linalg.norm(vv[1]-vv[0])/np.linalg.norm(vv[1]))
  boundary=float(100*np.linalg.norm(ww[1]-ww[0])/np.linalg.norm(ww[1]))
  # No quadrature combination: both are observed finite-difference sensitivities, not error bounds.
  maxchange=max(fine,boundary)
  rows.append(dict(law=law,radius_rh=rad,delta_acc_norm_over_a0_59=float(np.linalg.norm(vv[2])),
    resolution_35_to_47_pct=coarse,resolution_47_to_59_pct=fine,box_6_to_8_pct=boundary,
    conservative_max_observed_pct=maxchange,
    exploratory_1pct_stability_gate='PASS' if maxchange<1 else 'FAIL',
    caveat='1% is a diagnostic threshold chosen after exploratory calculations, NOT a preregistered criterion or certified error bound'))
out={'status':'EXPLORATORY_POSTPROCESS_ONLY','input_files':[{'name':f,'sha256':hashlib.sha256(b).hexdigest()} for f,b in zip(files,raw)],'definition':'Compare 47^3 to 59^3 at 6rh; compare 6rh to 8rh at spacing rh/8; same physical radial samples; denominator is finer/larger vector norm','limitations':['No new 3D Poisson solves','Resolution and box variations are not a full independent uncertainty bound','Zero-Dirichlet difference-potential boundary has not been physically validated','The 1% gate is exploratory and post-hoc, not preregistered','No Jeans dispersion, Hessian solver validation, B01-B24 or observational fit'],'results':rows}
p=root/'UDCT_v7_13_Joint_Grid_Box_StopGate_Audit.json';p.write_text(json.dumps(out,indent=2)+'\n')
for r in rows:print(r['law'],r['radius_rh'],'res %.3f%%'%r['resolution_47_to_59_pct'],'box %.3f%%'%r['box_6_to_8_pct'],r['exploratory_1pct_stability_gate'])
print('Saved',p)

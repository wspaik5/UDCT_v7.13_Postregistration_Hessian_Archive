#!/usr/bin/env python3
"""Exploratory truncated-source multipole boundary vs zero Dirichlet.
This is NOT an exterior-complete physical boundary and NOT v7.13 prereg execution.
"""
import json,hashlib
from pathlib import Path
import numpy as np
from scipy.fft import dstn,idstn
R=Path('/mnt/data'); source=R/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
s=source.read_text(); s=s[:s.index("out={'status'")]
s=s.replace(' pot=solve(rhs,h)', ' return rhs,h')
ns={'__file__':str(source)};exec(compile(s,str(source),'exec'),ns)
rh=ns['rh'];m=ns['m'];base_L=ns['L']

def solve_dirichlet(rhs,h,bfaces):
 n=rhs.shape[0]; v=rhs.copy(); hh=h*h
 # faces each is a 2D (n,n) array of boundary values
 for ax in range(3):
  low,high=bfaces[ax]
  if ax==0: v[0,:,:]-=low/hh;v[-1,:,:]-=high/hh
  if ax==1: v[:,0,:]-=low/hh;v[:,-1,:]-=high/hh
  if ax==2: v[:,:,0]-=low/hh;v[:,:,-1]-=high/hh
 return ns['solve'](v,h)

def run(lawname,side,n):
 ns['run'].__globals__['L']=side*rh
 law=next(z for z in m.PART_A_LAWS if z.name==lawname)
 rhs,h=ns['run'](n,law,10.)
 # dimensionless coordinate x/rh; source rescaled by rh^2/(a0 rh)
 src=rhs*rh/m.A0
 spacing=h/rh;coord=(np.arange(n)-(n-1)/2)*spacing
 X=np.meshgrid(coord,coord,coord,indexing='ij');flat=np.stack([v.ravel() for v in X],axis=1)
 weights=(src.ravel()*spacing**3)
 monopole=weights.sum();dipole=np.einsum('n,ni->i',weights,flat)
 r2=(flat**2).sum(axis=1)
 quad=np.einsum('n,ni,nj->ij',3*weights,flat,flat)-np.eye(3)*np.dot(weights,r2)
 def boundary_val(pos,degree):
  rad=np.sqrt((pos**2).sum(axis=-1));p=-monopole/rad/(4*np.pi)
  if degree>=1:p-=np.einsum('...i,i->...',pos,dipole)/(4*np.pi*rad**3)
  if degree>=2:p-=np.einsum('...i,ij,...j->...',pos,quad,pos)/(8*np.pi*rad**5)
  return p
 def faces(degree):
  bd=[]; u,v=np.meshgrid(coord,coord,indexing='ij');edge=side/2
  for axis in range(3):
   pair=[]
   for sign in (-1,1):
    pts=np.empty((n,n,3));pts[...,axis]=sign*edge
    other=[a for a in range(3) if a!=axis];pts[...,other[0]]=u;pts[...,other[1]]=v
    pair.append(boundary_val(pts,degree)*m.A0*rh)
   bd.append(pair)
  return bd
 zeros=[[np.zeros((n,n)),np.zeros((n,n))] for _ in range(3)]
 results={}; i=n//2;offset=int(round(1/spacing));
 for deg in (-1,0,1,2):
  f=zeros if deg<0 else faces(deg)
  phi=solve_dirichlet(rhs,h,f)
  # field at x=1 rh along x axis, on same grid
  ix=i+offset
  g=(phi[ix+1,i,i]-phi[ix-1,i,i])/(2*h*m.A0)
  results[str(deg)]={'phi_center_over_a0rh':float(phi[i,i,i]/(m.A0*rh)),'gx_at_rh_over_a0':float(g)}
 return {'law':lawname,'side_rh':side,'n':n,'monopole_scaled':float(monopole),'dipole_scaled':dipole.tolist(),'quadrupole_frobenius_scaled':float(np.linalg.norm(quad)),'results':results}

out={'status':'EXPLORATORY_TRUNCATED_SOURCE_MULTIPOLE_BOUNDARY','description':'Compare zero Dirichlet to monopole, dipole, quadrupole boundary values of truncated in-box delta-Poisson source; not a physical exterior completion','limitations':['Outside-box source omitted','Taylor Galactic field not valid arbitrarily far','Multipole expansion evaluated on cube faces near source, not guaranteed convergent','Quadrupole origin-dependent if lower moments nonzero','Not B01-B24 or Jeans validation'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':[]}
for law in ('A-Qs','A-f1/2'):
 for side,n in ((6,47),(8,63)):
  r=run(law,side,n);out['rows'].append(r)
  print(law,side,{k:round(v['gx_at_rh_over_a0'],9) for k,v in r['results'].items()},flush=True)
p=R/'UDCT_v7_13_Multipole_Boundary_Exploratory.json';p.write_text(json.dumps(out,indent=2)+'\n');print('SAVED',p)

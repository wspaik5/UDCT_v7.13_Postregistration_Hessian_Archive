#!/usr/bin/env python3
"""Independent analytic Plummer Poisson sign/boundary test; NOT a GQUMOND solver."""
import json, math, hashlib
from pathlib import Path
import numpy as np
from scipy.fft import dstn, idstn

def solve(rhs, h):
 n=rhs.shape[0]; k=np.arange(1,n+1)
 eig=2*(np.cos(np.pi*k/(n+1))-1)/h**2
 return idstn(dstn(rhs,type=1,norm='ortho')/(eig[:,None,None]+eig[None,:,None]+eig[None,None,:]),type=1,norm='ortho')

def lap(u,h):
 a=np.pad(u,1)
 return (a[2:,1:-1,1:-1]+a[:-2,1:-1,1:-1]+a[1:-1,2:,1:-1]+a[1:-1,:-2,1:-1]+a[1:-1,1:-1,2:]+a[1:-1,1:-1,:-2]-6*u)/h**2

def run(n,nu):
 # Nondimensional GM=b=1, box [-4,4]^3. Exact Plummer Phi=-nu/sqrt(r^2+1)
 box=4.; h=2*box/(n+1)
 t=-box+h*np.arange(1,n+1)
 x=t[:,None,None];y=t[None,:,None];z=t[None,None,:]
 r2=x*x+y*y+z*z
 exact=-nu/np.sqrt(1+r2)
 source=3*nu/(1+r2)**2.5  # lap(Phi)=4piG rho >=0
 # Inhomogeneous Dirichlet boundary, via known ghost values at faces.
 rhs=source.copy()
 face=-nu/np.sqrt(1+box*box+t[:,None]**2+t[None,:]**2)
 # face indexed by remaining two dimensions; same values for all six faces
 rhs[0,:,:]-=face/h**2;rhs[-1,:,:]-=face/h**2
 rhs[:,0,:]-=face/h**2;rhs[:,-1,:]-=face/h**2
 rhs[:,:,0]-=face/h**2;rhs[:,:,-1]-=face/h**2
 phi=solve(rhs,h)
 # check full operator with nonzero boundary
 residual=lap(phi,h)-rhs
 rel=float(np.linalg.norm(phi-exact)/np.linalg.norm(exact))
 return {'grid':n,'spacing_in_Plummer_scales':h,'relative_L2_error':rel,
         'relative_discrete_residual':float(np.linalg.norm(residual)/np.linalg.norm(rhs)),
         'central_potential':float(phi[n//2,n//2,n//2]),
         'central_source_positive':bool(source[n//2,n//2,n//2]>0),
         'boundary':'exact Plummer Dirichlet on all six faces'}

results={}
for name,nu in [('Newtonian_nu_1',1.),('constant_response_nu_1p5',1.5)]:
 rows=[run(n,nu) for n in (20,40,80)]
 ratios=[rows[i]['relative_L2_error']/rows[i+1]['relative_L2_error'] for i in (0,1)]
 assert all(r['relative_discrete_residual']<1e-10 for r in rows)
 assert all(r['central_source_positive'] for r in rows)
 assert all(3.0<v<4.5 for v in ratios),ratios
 results[name]={'runs':rows,'error_reduction_ratios':ratios}
# The constant-nu test must scale linearly (same shape, exactly 1.5 times Newtonian)
for a,b in zip(results['Newtonian_nu_1']['runs'],results['constant_response_nu_1p5']['runs']):
 assert abs(b['central_potential']/a['central_potential']-1.5)<1e-10
report={'status':'PASS: independent manufactured physical Plummer Poisson sign, normalization and nonzero Dirichlet boundary control',
 'scope':'Dimensionless Newtonian and constant-response controls only; no GQUMOND Hessian source or Hydrus I field solution',
 'analytic_identity':'Phi=-nu GM/sqrt(r^2+b^2); Laplacian Phi=3 nu GM b^2/(r^2+b^2)^(5/2) = 4 pi G nu rho',
 'results':results,
 'limitations':['GM=b=1 nondimensional test, not an SI units verification', 'constant nu=1.5 is not A-Qs or A-Qd', 'full 3D GQUMOND equation sign and boundary conditions not independently established', 'B01-B24 Hessian/Jeans tests not performed'],
 'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
p=Path('/mnt/data/UDCT_v7_13_Poisson_Sign_Units_Boundary_Gate.json')
p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':report['status'],'results':{k:{'relative_errors':[r['relative_L2_error'] for r in v['runs']],'ratios':v['error_reduction_ratios']} for k,v in results.items()},'saved':str(p)},indent=2))

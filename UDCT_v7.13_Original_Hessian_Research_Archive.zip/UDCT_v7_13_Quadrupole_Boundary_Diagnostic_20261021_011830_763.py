#!/usr/bin/env python3
"""Exploratory quadrupole moment audit of frozen 3D delta-Poisson source.
No new Poisson solve, no physical asymptotic boundary, no prereg B01-B24 execution.
"""
from pathlib import Path
import json,hashlib
import numpy as np
root=Path(__file__).resolve().parent
src=root/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
script=src.read_text().split("out={'status'")[0]
start=script.index(' pot=solve(rhs,h)')
end=script.index('\nout={',start) if '\nout={' in script[start:] else len(script)
script=script[:start]+''' axis=(np.arange(n)-(n-1)/2)*h
 xx,yy,zz=np.meshgrid(axis,axis,axis,indexing='ij')
 coords=(xx,yy,zz)
 r2p=xx*xx+yy*yy+zz*zz
 dv=h**3
 absint=float(np.abs(rhs).sum()*dv)
 quad=np.array([[float(np.sum(rhs*(3*coords[i]*coords[j]-(r2p if i==j else 0)))*dv) for j in range(3)] for i in range(3)])
 # Quadrupole tensor normalized by absolute source integral and rh^2
 qnorm=quad/(absint*rh**2)
 outer=r2p >= (0.8*L/2)**2
 outerq=np.array([[float(np.sum((rhs*(3*coords[i]*coords[j]-(r2p if i==j else 0)))[outer])*dv) for j in range(3)] for i in range(3)])
 return {'law':law.name,'box_side_rh':L/rh,'n':n,'ell_pc':ellpc,
 'quadrupole_frobenius_over_absint_rh2':float(np.linalg.norm(qnorm)),
 'quadrupole_normalized_tensor':qnorm.tolist(),
 'outer_quadrupole_norm_over_total_quad_norm':float(np.linalg.norm(outerq)/max(np.linalg.norm(quad),1e-300)),
 'quadrupole_trace_normalized':float(np.trace(qnorm)),
 'absolute_source_integral':absint}
'''
ns={'__file__':str(src)}
exec(compile(script,str(src),'exec'),ns)
rows=[]
for name in ('A-Qs','A-f1/2'):
 law=next(z for z in ns['m'].PART_A_LAWS if z.name==name)
 for side,n in ((6,47),(8,63)):
  ns['run'].__globals__['L']=side*ns['rh']
  row=ns['run'](n,law,10.)
  rows.append(row)
  print(name,side,'quadrupole',row['quadrupole_frobenius_over_absint_rh2'],'outer ratio',row['outer_quadrupole_norm_over_total_quad_norm'],flush=True)
out={'status':'EXPLORATORY_MULTIPOLE_DIAGNOSTIC_NOT_BOUNDARY_SOLUTION',
 'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
 'definition':'Q_ij = integral S(x) (3 x_i x_j - r^2 delta_ij) dV; normalized Frobenius by integral |S| dV times rh^2',
 'limitations':['Quadrupole is origin-dependent when monopole/dipole nonzero','Outer fraction uses Frobenius norms; may exceed unity because of cancellation','No exterior source included','No multipole boundary imposed or Poisson solved','No physically validated Galactic far field','No Jeans or prereg B01-B24 results'],
 'results':rows}
p=root/'UDCT_v7_13_Quadrupole_Boundary_Diagnostic.json'
p.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print('saved',p)

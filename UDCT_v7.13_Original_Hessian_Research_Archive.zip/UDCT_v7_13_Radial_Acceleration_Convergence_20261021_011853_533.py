#!/usr/bin/env python3
"""Exploratory radial vector acceleration audit; not preregistered B01-B24.
Uses frozen v7.10 source and finite zero-Dirichlet delta-potential box.
"""
import json, hashlib
from pathlib import Path
import numpy as np
root=Path('/mnt/data')
original=root/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
s=original.read_text()
s=s[:s.index("out={'status'")]
old=" return {'n':n,'spacing_over_rh':h/rh"
new=""" samples=[]
 for target in (0.5,1.,2.):
  ix=int(round(mid+target*rh/h))
  if ix+1>=n: raise ValueError('sample outside grid')
  vec=np.array([(pot[ix+1,mid,mid]-pot[ix-1,mid,mid]),(pot[ix,mid+1,mid]-pot[ix,mid-1,mid]),(pot[ix,mid,mid+1]-pot[ix,mid,mid-1])])/(2*h*m.A0)
  samples.append({'requested_radius_rh':target,'actual_radius_rh':(ix-mid)*h/rh,'delta_acceleration_vector_over_a0':vec.tolist(),'delta_acceleration_norm_over_a0':float(np.linalg.norm(vec))})
 return {'radial_samples':samples,'n':n,'spacing_over_rh':h/rh"""
assert old in s
s=s.replace(old,new)
ns={'__file__':str(original)}
exec(compile(s,str(original),'exec'),ns)
rows=[]
for lawname in ('A-Qs','A-f1/2'):
 law=next(x for x in ns['m'].PART_A_LAWS if x.name==lawname)
 for n in (35,47,59):
  row=ns['run'](n,law,10.)
  rows.append(row)
  print(lawname,n,[(round(p['actual_radius_rh'],4),round(p['delta_acceleration_norm_over_a0'],9)) for p in row['radial_samples']],flush=True)
comparisons=[]
for lawname in ('A-Qs','A-f1/2'):
 a,b,c=[r for r in rows if r['law']==lawname]
 for k,target in enumerate((.5,1.,2.)):
  v=[np.array(r['radial_samples'][k]['delta_acceleration_vector_over_a0']) for r in (a,b,c)]
  comparisons.append({'law':lawname,'target_rh':target,'relative_vector_change_35_to_47':float(np.linalg.norm(v[1]-v[0])/max(np.linalg.norm(v[1]),1e-300)),'relative_vector_change_47_to_59':float(np.linalg.norm(v[2]-v[1])/max(np.linalg.norm(v[2]),1e-300)),'actual_sample_radii_rh':[r['radial_samples'][k]['actual_radius_rh'] for r in (a,b,c)]})
output={'status':'EXPLORATORY_NOT_PREREGISTERED','source_solver_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'boundary':'delta_phi=0 on finite cube of side 6 rh','method':'central finite differences at nearest grid nodes to requested +x radii, with sampling-position mismatch; no interpolation; compare vectors','limitations':['Sample coordinates vary slightly with resolution','Fixed finite Dirichlet boundary not physical','No full gravitational potential or stellar Jeans fit','No B01-B24 decisions'],'results':rows,'comparisons':comparisons}
path=root/'UDCT_v7_13_Radial_Acceleration_Convergence.json';path.write_text(json.dumps(output,indent=2)+'\n')
print('saved',path)
for c in comparisons:print(c['law'],c['target_rh'],'35→47',f"{c['relative_vector_change_35_to_47']*100:.2f}%",'47→59',f"{c['relative_vector_change_47_to_59']*100:.2f}%")

#!/usr/bin/env python3
"""Exploratory common-coordinate interpolation, finite-box delta-potential; NOT prereg B01-B24."""
import json,hashlib
from pathlib import Path
import numpy as np
root=Path('/mnt/data'); src=root/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
s=src.read_text().split("out={'status'")[0]
needle=" return {'n':n,'spacing_over_rh':h/rh"
assert needle in s
replacement='''
 samples=[]
 for target in (0.5,1.,2.):
  position=target*rh/h+mid
  lo=int(np.floor(position));hi=lo+1;alpha=position-lo
  assert lo>=1 and hi+1<n
  def grad_at(ix):
   return np.array([(pot[ix+1,mid,mid]-pot[ix-1,mid,mid]),(pot[ix,mid+1,mid]-pot[ix,mid-1,mid]),(pot[ix,mid,mid+1]-pot[ix,mid,mid-1])])/(2*h*m.A0)
  v=(1-alpha)*grad_at(lo)+alpha*grad_at(hi)
  samples.append({'target_radius_rh':target,'fractional_grid_index':float(position),'interpolated_delta_gradient_vector_over_a0':v.tolist(),'norm_over_a0':float(np.linalg.norm(v))})
 return {'n':n,'law':law.name,'ell_pc':ellpc,'spacing_over_rh':float(h/rh),'samples':samples,'relative_discrete_residual':float(residual)}
'''
s=s.replace(needle,replacement+' # unused return stub: '+needle)
ns={'__file__':str(src)}
exec(compile(s,str(src),'exec'),ns)
rows=[]
for name in ('A-Qs','A-f1/2'):
 law=next(z for z in ns['m'].PART_A_LAWS if z.name==name)
 for box,n in ((6,47),(8,63)):
  ns['run'].__globals__['L']=box*ns['rh']
  result=ns['run'](n,law,10.)
  result['box_side_over_rh']=box
  rows.append(result)
  print(name,box,n,[(p['target_radius_rh'],round(p['norm_over_a0'],9)) for p in result['samples']],flush=True)
comp=[]
for name in ('A-Qs','A-f1/2'):
 rr=[z for z in rows if z['law']==name]
 for k,target in enumerate((.5,1.,2.)):
  v0=np.array(rr[0]['samples'][k]['interpolated_delta_gradient_vector_over_a0']);v1=np.array(rr[1]['samples'][k]['interpolated_delta_gradient_vector_over_a0'])
  comp.append({'law':name,'radius_rh':target,'relative_vector_change_6_to_8_pct':float(100*np.linalg.norm(v1-v0)/np.linalg.norm(v1))})
out={'status':'EXPLORATORY_NOT_PREREGISTERED','method':'box-side 6rh vs 8rh at identical grid spacing rh/8; common physical coordinates','boundary':'zero Dirichlet delta potential at box faces; not justified as physical','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'limitations':['Only two finite box sizes; not extrapolated to infinity','Boundary remains unphysical','No full Jeans solution','No B01-B24 decisions'],'results':rows,'comparisons':comp}
p=root/'UDCT_v7_13_Radial_Box_Size_Audit.json';p.write_text(json.dumps(out,indent=2)+'\n')
for x in comp:print(x)
print('saved',p)

#!/usr/bin/env python3
"""Exploratory boundary/source-localization audit of frozen 3D delta-source.
No preregistered B01-B24 result, no physical boundary validation.
"""
import json, hashlib
from pathlib import Path
import numpy as np
root=Path('/mnt/data')
src=root/'UDCT_v7_13_Hydrus_3D_DeltaPotential_Exploratory.py'
s=src.read_text().split("out={'status'")[0]
s=s.replace(' pot=solve(rhs,h)', '''
 # Volume-integrated source and outer-shell contribution, before Poisson solve.
 axis=(np.arange(n)-(n-1)/2)*h
 xx,yy,zz=np.meshgrid(axis,axis,axis,indexing='ij')
 rad=np.sqrt(xx**2+yy**2+zz**2)
 shell=rad>=0.8*(L/2)
 total_abs=float(np.sum(np.abs(rhs))*h**3)
 shell_abs=float(np.sum(np.abs(rhs[shell]))*h**3)
 monopole=float(np.sum(rhs)*h**3)
 dipole=np.array([np.sum(rhs*xx),np.sum(rhs*yy),np.sum(rhs*zz)])*h**3
 shell_rms=float(np.sqrt(np.mean(rhs[shell]**2)))
 inner_rms=float(np.sqrt(np.mean(rhs[~shell]**2)))
 return {'n':n,'box_side_over_rh':float(L/rh),'spacing_over_rh':float(h/rh),'law':law.name,'ell_pc':ellpc,'absolute_source_integral':total_abs,'signed_source_integral':monopole,'signed_to_absolute_ratio':monopole/max(total_abs,1e-300),'outer_shell_abs_fraction':shell_abs/max(total_abs,1e-300),'outer_shell_rms_to_inner_rms':shell_rms/max(inner_rms,1e-300),'dipole_moment_norm_over_abs_integral_rh':float(np.linalg.norm(dipole)/max(total_abs*rh,1e-300))}
 pot=solve(rhs,h)''')
ns={'__file__':str(src)}
exec(compile(s,str(src),'exec'),ns)
rows=[]
for name in ('A-Qs','A-f1/2'):
 law=next(z for z in ns['m'].PART_A_LAWS if z.name==name)
 for box,n in ((6,47),(8,63)):
  ns['run'].__globals__['L']=box*ns['rh']
  row=ns['run'](n,law,10.)
  rows.append(row)
  print(name,box,'shell fraction',row['outer_shell_abs_fraction'],'rms ratio',row['outer_shell_rms_to_inner_rms'],flush=True)
out={'status':'EXPLORATORY_SOURCE_LOCALIZATION_NOT_PHYSICAL_BOUNDARY','description':'Compute delta-Poisson source spatial localization before solving. Outer shell defined r >= 0.8 times cube half-side; includes corners. Nonzero shell source is a warning that a low-order multipole boundary condition may be unreliable.','source_script_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'limitations':['This measures localization within the finite box, not missing source outside it','Nonzero multipole moments do not prove physical asymptotic boundary conditions','Fixed linear Galactic Taylor field is not valid arbitrarily far away','No Jeans solution, B01-B24 or observation fit'],'results':rows}
p=root/'UDCT_v7_13_Source_Localization_Boundary_Audit.json'
p.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print('SAVED',p)

#!/usr/bin/env python3
"""Exploratory B09 six-arm common-grid audit; not a preregistered confirmatory outcome."""
from pathlib import Path
import json,csv,hashlib,importlib.util,sys,time
import numpy as np
R=Path('/mnt/data/v713_b07_run')
plan=json.loads((R/'preregistration_plan.json').read_text())
for n,d in plan['frozen_hashes'].items():
 assert hashlib.sha256((R/n).read_bytes()).hexdigest()==d,n
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load(R/'UDCT_v7_12_Preregistration_Jeans_Transition.py','v712_six_audit')
proto=load(R/'UDCT_v7_13_Six_Arm_Decision_Prototype.py','v713_six_proto')
m=old.load_frozen();b=m.load_baseline();obj=b.DWARFS['Hydrus I']
with (R/'adaptive_brackets.csv').open() as f: t=list(csv.DictReader(f))[8]
assert t['axis']=='beta' and t['law']=='A-f2' and float(t['fixed_coordinate'])==1.5
configs=[('default',b.make_grid('default')),('refined',b.make_grid('refined')),('validation',b.Grid(radial=1440,polar=96,azimuth=144,disk_radial=480,disk_azimuth=256,disk_height=48))]
all_arms={float(t['lo']):{},float(t['hi']):{}}
per_arm=[];t0=time.monotonic()
for name,grid in configs:
 e,h=b.V706.galactic_field(obj,grid)[:2]
 for inner in (.002,.0005):
  st=b.model_state(obj,'Tapered cusp',b.mesh('Tapered cusp',grid,rmin=inner),e,h,grid,next(l for l in b.PART_A_LAWS if l.name==t['law']),float(t['fixed_coordinate']),0.)
  _,force=b.V706.work_from_state(st)
  _,ref=b.V706.aperture_jeans(st,force,obj.re_pc)
  pressure,_,_=m.solve(st['r'],st['rho'],force,0.)
  sigma=np.divide(pressure,st['rho'],out=np.zeros_like(pressure),where=st['rho']>1e-280)
  vref2=float(np.interp(1.,st['r']/st['rh'],st['gn']))*st['rh']
  gate=float(np.max(abs(sigma-ref))/vref2)
  assert np.isfinite(gate) and gate<1e-10
  for beta in all_arms:
   rec=m.summary(st['r'],st['rho'],force,beta,st['rh'],st['gn'])
   key=f'{name}|{inner:g}'
   all_arms[beta][key]={'common':np.asarray(rec['common_sigma2_over_vref2']),'native_min':rec['min_sigma2_kms2']*1e6/rec['vref2_si'],'gate':True}
   per_arm.append({'beta':beta,'arm':key,'native_min':all_arms[beta][key]['native_min'],'isotropic_gate':gate})
 print('completed',name,flush=True)
results={str(beta):proto.decide(arms) for beta,arms in all_arms.items()}
status=proto.bracket(*results.values())
# Common grid extends below the rmin=0.002 arms; that portion is interpolated by edge holding.
# Do not interpret common-radius agreement there as independently sampled.
report={'classification':'EXPLORATORY ONLY, NOT CONFIRMATORY','target':'B09','sha256_verified':True,'six_arms_executed':True,'hessian_executed':False,'endpoint_results':results,'bracket_status':status,'arms':per_arm,'common_grid_warning':'COMMON_X begins at 0.002 r_h. Arms with rmin=0.002 are sampled at that lower edge, not below it.','elapsed_seconds':round(time.monotonic()-t0,2)}
out=Path('/mnt/data/UDCT_v7_13_B09_Six_Arm_Profile_Exploratory.json');out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'endpoint_statuses':{k:v['status'] for k,v in results.items()},'bracket_status':status,'elapsed_seconds':report['elapsed_seconds']},indent=2));print('SAVED',out)

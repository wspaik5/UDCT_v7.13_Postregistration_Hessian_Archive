from pathlib import Path
import sys,importlib.util,json,hashlib,time,numpy as np
R=Path('/mnt/data/v713_post_work');plan=json.loads((R/'preregistration_plan.json').read_text())
for n,h in plan['frozen_hashes'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h
spec=importlib.util.spec_from_file_location('frozen_712_validation',R/'UDCT_v7_12_Preregistration_Jeans_Transition.py');v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
m=v.load_frozen();b=m.load_baseline();obj=b.DWARFS['Hydrus I'];t=time.monotonic()
grid=b.Grid(radial=1440,polar=96,azimuth=144,disk_radial=480,disk_azimuth=256,disk_height=48)
e,h,mass=b.V706.galactic_field(obj,grid);print('FIELD seconds',round(time.monotonic()-t,2),flush=True)
results=[]
for inner in (.002,.0005):
 st=b.model_state(obj,'Tapered cusp',b.mesh('Tapered cusp',grid,rmin=inner),e,h,grid,b.BASE_LAW,1.,0.)
 _,force=b.V706.work_from_state(st)
 _,ref=b.V706.aperture_jeans(st,force,obj.re_pc)
 pressure,_,_=m.solve(st['r'],st['rho'],force,0.)
 sigma=np.divide(pressure,st['rho'],out=np.zeros_like(pressure),where=st['rho']>1e-280)
 vref2=float(np.interp(1.,st['r']/st['rh'],st['gn']))*st['rh']
 gate=float(np.max(abs(sigma-ref))/vref2)
 assert np.isfinite(gate) and gate<1e-10,gate
 for beta in (.35,.4):
  rec=m.summary(st['r'],st['rho'],force,beta,st['rh'],st['gn'])
  results.append({'inner_rh':inner,'beta':beta,'min_sigma2_kms2':rec['min_sigma2_kms2'],'min_normalized':rec['min_sigma2_kms2']*1e6/rec['vref2_si'],'min_radius_rh':rec['min_at_r_over_rh'],'isotropic_gate_error':gate})
 print('inner',inner,'done',flush=True)
out={'status':'EXPLORATORY validation-grid B01 two arms; NOT six-arm full profile classification','source_hashes_verified':True,'grid':grid.__dict__,'field_seconds':round(time.monotonic()-t,2),'results':results,'hessian_total':False,'confirmatory':False}
p=Path('/mnt/data/UDCT_v7_13_B01_validation_grid_exploratory.json');p.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
